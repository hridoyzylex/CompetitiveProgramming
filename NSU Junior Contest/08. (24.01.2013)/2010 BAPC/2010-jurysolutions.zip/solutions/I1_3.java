/*
 * BAPC 2010
 * Jeroen Bransen
 */

import java.io.*;
import java.util.*;

public class keylogger_jb {
   public static void main(String[] args) throws Exception {
      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      PrintStream out = new PrintStream(new BufferedOutputStream(System.out));
      int tests = Integer.parseInt(in.readLine());
      while(tests-- > 0) {
         String line = in.readLine();
         LinkedList<Character> password = new LinkedList<Character>();
         int position = 0;
         for (int i=0;i<line.length();i++){
         char ch = line.charAt(i); 
         switch(ch){
            case '-': if (position>0) password.remove(--position); break;
            case '>': if (position<password.size()) position++; break;
            case '<': if (position>0) position--; break;
            default: {
                  password.add(position,ch);
                  position++;
               }
            }
         }
         for(Character c : password)
            out.print(c);
         out.println();
      }
      out.close();
   }
}
