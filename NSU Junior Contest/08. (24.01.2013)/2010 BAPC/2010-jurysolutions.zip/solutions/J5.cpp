//Johan de Ruiter (+Prime Suspects TCR)

#include <iostream>  
#include <sstream>  
#include <string>  
#include <vector>  
#include <queue>  
#include <set>  
#include <map>  
#include <cstdio>  
#include <cstdlib>  
#include <cctype>  
#include <cmath>  
#include <list>  
#include <numeric> 
#include <ctime>
#include <algorithm>
#include <cstring>
using namespace std;  
  
typedef vector<int> vi;  
typedef vector<vi> vvi;  
typedef vector<string> vs;  
typedef vector<vs> vvs; 
#define pb push_back  
#define sz(v) ((int)(v).size()) 


const int M = 500, N = 500;  bool graph[M][N]; bool seen[N];
int matchL[M], matchR[N]; 
                
bool bpmmatch (int u, int n)
{ for (int v = 0; v < n; v++)  if (graph[u][v] && !seen[v])
  { seen[v] = true;
    if (matchR[v] < 0 || bpmmatch(matchR[v], n))
    { matchL[u] = v;  matchR[v] = u;  return true;}
  }
  return false;
}
                
int bpm (int m, int n)
{ memset(matchL, -1, sizeof(matchL));  memset(matchR, -1, sizeof(matchR));
  int cnt = 0;
  for (int i = 0; i < m; i++)
  { memset(seen, 0, sizeof(seen));  if (bpmmatch(i, n))  cnt++;}
  return cnt;
}

int main()
{
  int runs,run,i,j,k;
  char buf[10000];
  scanf("%d",&runs);

  for(run=0;run<runs;run++)
  {
    int H,V; int x,y;
    vs Hw,Vw; 
    vi Hx,Hy,Vx,Vy;

    scanf("%d %d",&H,&V);
    for(j=0;j<H;j++)
    {
      scanf("%d %d %s",&x,&y,buf);
      Hx.pb(x); Hy.pb(y);
      Hw.pb(buf);
    }
    for(j=0;j<V;j++)
    {
      scanf("%d %d %s",&x,&y,buf);
      Vx.pb(x); Vy.pb(y);
      Vw.pb(buf);
    }

    memset(graph,false,sizeof(graph));

    for(j=0;j<H;j++)
      for(i=0;i<V;i++)
      {
        if(Vx[i]<Hx[j]||Vx[i]>=Hx[j]+sz(Hw[j])) continue;
        if(Hy[j]<Vy[i]||Hy[j]>=Vy[i]+sz(Vw[i])) continue;

        if(Hw[j][Vx[i]-Hx[j]]!=Vw[i][Hy[j]-Vy[i]])       
          graph[j][i]=true;
      }

    printf("%d\n",H+V-bpm(H,V));

  }
  return 0;
}
