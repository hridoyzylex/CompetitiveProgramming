/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>

#define MAXL 1000000

char line[MAXL + 10];
char stack[2][MAXL + 10];
int s[2];

char pop(int i) {
	return s[i] ? stack[i][--s[i]] : 0;
}

void push(int i, char c) {
	stack[i][s[i]++] = c;
}

void testcase() {
	int i;
	char c;
	scanf("%s\n",line);
	s[0] = s[1] = 0;
	for(i = 0; line[i]; i++) {
		if(line[i] == '-') {
			pop(0);
		} else if(line[i] == '<') {
			c = pop(0);
			if(c)
				push(1,c);
		} else if(line[i] == '>') {
			c = pop(1);
			if(c)
				push(0,c);
		} else {
			push(0,line[i]);
		}
	}
	while(c = pop(0)) {
		push(1,c);
	}
	while(c = pop(1)) {
		putchar(c);
	}
	putchar('\n');
}

int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
