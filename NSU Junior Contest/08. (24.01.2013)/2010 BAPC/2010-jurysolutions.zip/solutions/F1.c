/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAXW 100
#define MAXH 100

bool doorE[MAXW*2+10][MAXH*2+10];
bool doorW[MAXW*2+10][MAXH*2+10];
bool doorN[MAXW*2+10][MAXH*2+10];
bool doorS[MAXW*2+10][MAXH*2+10];
bool done[MAXW*2+10][MAXH*2+10];

// Explore the maze
int ex, ey;
char line[10];
void dfs(int x, int y) {
	int i;
	done[x][y] = true;
	scanf("%s", line);
	for(i=0;line[i];i++) {
		if(line[i] == 'N') {
			doorN[x][y] = doorS[x][y-1] = true;
			if(!done[x][y-1]) {
				puts("N"); fflush(NULL);
				dfs(x, y-1);
				puts("S"); fflush(NULL);
				scanf("%s", line);
			}
		} else if(line[i] == 'S') {
			doorS[x][y] = doorN[x][y+1] = true;
			if(!done[x][y+1]) {
				puts("S"); fflush(NULL);
				dfs(x, y+1);
				puts("N"); fflush(NULL);
				scanf("%s", line);
			}
		} else if(line[i] == 'E') {
			doorE[x][y] = doorW[x+1][y] = true;
			if(!done[x+1][y]) {
				puts("E"); fflush(NULL);
				dfs(x+1, y);
				puts("W"); fflush(NULL);
				scanf("%s", line);
			}
		} else if(line[i] == 'W') {
			doorW[x][y] = doorE[x-1][y] = true;
			if(!done[x-1][y]) {
				puts("W"); fflush(NULL);
				dfs(x-1, y);
				puts("E"); fflush(NULL);
				scanf("%s", line);
			}
		} else if(line[i] == '*') {
			ex = x;
			ey = y;
		} else {
			fprintf(stderr, "Invalid character in input: '%c'\n", line[i]);
			return;
		}
	}
}

// Find the answer
#define QUEUE_LEN (MAXW*MAXH)
struct queue_item {
	int x, y, s;
} Q[QUEUE_LEN];

int queue_start, queue_len;

void push(int x, int y, int s) {
	int idx = queue_start + queue_len;
	if(idx >= QUEUE_LEN) idx -= QUEUE_LEN;
	queue_len++;
	if(queue_len > QUEUE_LEN)
		fprintf(stderr, "Cornercase, Q is too small!!\n");
	Q[idx].x = x;
	Q[idx].y = y;
	Q[idx].s = s;
}

struct queue_item pop() {
	struct queue_item ret = Q[queue_start];
	queue_start++;
	if(queue_start >= QUEUE_LEN) queue_start -= QUEUE_LEN;
	queue_len--;
	return ret;
}

int getAnswer() {
	struct queue_item top;
	memset(done, false, sizeof(done));
	queue_start = queue_len = 0;
	push(MAXW+5, MAXH+5, 0);
	while(queue_len > 0) {
		top = pop();
		if(done[top.x][top.y]) continue;
		done[top.x][top.y] = true;
		if(top.x == ex && top.y == ey)
			return top.s;
		if(doorN[top.x][top.y])
			push(top.x, top.y-1, top.s+1);
		if(doorS[top.x][top.y])
			push(top.x, top.y+1, top.s+1);
		if(doorE[top.x][top.y])
			push(top.x+1, top.y, top.s+1);
		if(doorW[top.x][top.y])
			push(top.x-1, top.y, top.s+1);
	}

	return -1;
}

void testcase() {
	memset(doorE, false, sizeof(doorE));
	memset(doorW, false, sizeof(doorW));
	memset(doorN, false, sizeof(doorN));
	memset(doorS, false, sizeof(doorS));
	memset(done, false, sizeof(done));

	ex = -1;
	ey = -1;
	dfs(MAXW+5, MAXH+5);
	if(ex == -1 || ey == -1)
		printf("-1\n");
	else
		printf("%d\n", getAnswer());
	fflush(NULL);
}

int main() {
	int t;
	scanf("%d", &t);
	while(t--) {
		testcase();
	}
	return 0;
}
