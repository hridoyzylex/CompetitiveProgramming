// Problem: Maze Recognition
// Author: Rudy van Vliet
// Date: 18 October 2010

// Program uses Depth First Search to construct the maze, and then uses
// Floodfill to find the shortest path to the exit.
// Because MaxDimension = 100, there are at most 10,000 rooms.
// Hence, the recursive Depth First Search should not cause
// stack overflow problems.
// Program seems to work well.

#include <iostream>
#include <cstring>
using namespace std;

const int MaxDimension = 100;
const char EOL = '\n';

int Maze[2*MaxDimension-1][2*MaxDimension-1];
      // For each room in the maze an integer 0..15,
      // which codes for the doors to other rooms
      //   1: door to the North
      //   2: door to the East
      //   4: door to the West
      //   8: door to the South
      // We let position (0,0) be the upper left corner of the maze.
      // Coordinate x runs in horizontal direction,
      // coordinate y runs in vertical direction.
const int UnknownRoom = -1;
      // We have not visited this room in the maze, yet.
      // Of course, this default value must be different
      // from all `real' values 0..15.
int XExit, YExit;
const int UnknownCoordinate = -1;
      // Of course, this default value must be different
      // from all `real' values 0..2*MaxDimension-2.

class Position
{ public: int x,
              y;

  public: Position (int initx, int inity)
  { x = initx;
    y = inity;
  }

};
Position* Queue[MaxDimension*MaxDimension];

int Distance[2*MaxDimension-1][2*MaxDimension-1];
const int DefaultDistance = -1;
      // Default value if we cannot find the exit.
      // Of course, this value must be different from all real values.

//************************************************************************

void DFS (int x, int y)
 // Perform a Depth First Search from room (x,y), visiting only those
 // rooms that have not been visited before.
 // For this, we first have to read a line with possible moves that we
 // can make from room (x,y).
 // Pre: (x,y) is valid position in the maze.
{ char moves[6],
       newmoves[6],
       moveback;
  int length,
      i,
      newx, newy;

  Maze[x][y] = 0;  // no longer unknown
  cin >> moves;
  length = strlen (moves);  // always positive

  if (moves[length-1]== '*')
    // the exit
  { if (XExit==UnknownCoordinate)
    { XExit = x;
      YExit = y;
    }
    else
      cout << "Second exit.\n";

    length --;  // we will not use last position in moves any further,
                // since it does not describe a possible move
  }

  for (i=0;i<length;i++)
  { switch (moves[i])
    { case 'N': newx = x;
                newy = y-1;
                moveback = 'S';
                Maze[x][y] = Maze[x][y] | 1;
                break;
      case 'E': newx = x+1;
                newy = y;
                moveback = 'W';
                Maze[x][y] = Maze[x][y] | 2;
                break;
      case 'W': newx = x-1;
                newy = y;
                moveback = 'E';
                Maze[x][y] = Maze[x][y] | 4;
                break;
      case 'S': newx = x;
                newy = y+1;
                moveback = 'N';
                Maze[x][y] = Maze[x][y] | 8;
                break;
      default: cout << "Unknown move.\n";
    }  // switch
           
    if ((newx<0) || (newx>2*MaxDimension-2)
       || (newy<0) || (newy>2*MaxDimension-2))
      cout << "Coordinates out of bounds.\n";
    else
    { if (Maze[newx][newy]==UnknownRoom)
      { cout << moves[i] << EOL;
        fflush (NULL);
        DFS (newx, newy);
        cout << moveback << EOL;
        fflush (NULL);
        cin >> newmoves;
        if (strcmp (moves, newmoves) != 0)
          cout << "Possible moves in room (" << x << "," << y
               << ") are not consistent.\n";
      }
    }

  }  // for i

}  // DFS

//************************************************************************

bool CheckPosition (int newx, int newy, int newdist, int &last)
 // Check if position (newx, newy) has been visited by the Floodfill before.
 // If not, add it to the Queue.
 // Return: true   if (newx, newy) happens to be the exit
 //         false  otherwise
{
  if (Distance[newx][newy] == DefaultDistance)  // first visit
  { Distance[newx][newy] = newdist;
    if (last < MaxDimension*MaxDimension-1)
    { last ++;
      Queue[last] = new Position (newx, newy);
    }
    else
      cout << "Queue is too small.\n";
  }

  if ((newx==XExit) && (newy==YExit))
    return true;
  else
    return false;

}  // CheckPosition

//************************************************************************

int ComputeDistance (int startx, int starty)
 // Compute distance from (startx,starty) to (XExit,YExit).
 // Use a Floodfill for this.
 // Use a Queue in which we store positions at most once
{ int x, y,
      newx, newy,
      first, last,  // positions in Queue
      i,
      code,         // entry in Maze
      dist;         // a distance
  bool found;

  for (x=0;x<2*MaxDimension-1;x++)
    for (y=0;y<2*MaxDimension-1;y++)
      Distance[x][y] = DefaultDistance;

  Distance[startx][starty] = 0;
  first = 0;
  last = 0;
  Queue[last] = new Position (startx, starty);

  found = false;

  if ((startx==XExit) && (starty==YExit))
    found = true;

  while (!found && (first <= last))
  {
    x = Queue[first]->x;
    y = Queue[first]->y;
    first ++;

    code = Maze[x][y];
    dist = Distance[x][y];

    if (code & 1)  // we can go north
    { newx = x;
      newy = y-1;
      found = CheckPosition (newx, newy, dist+1, last);
    }

    if (!found && (code & 2))  // we can go east
    { newx = x+1;
      newy = y;
      found = CheckPosition (newx, newy, dist+1, last);
    }

    if (!found && (code & 4))  // we can go west
    { newx = x-1;
      newy = y;
      found = CheckPosition (newx, newy, dist+1, last);
    }

    if (!found && (code & 8))  // we can go south
    { newx = x;
      newy = y+1;
      found = CheckPosition (newx, newy, dist+1, last);
    }

  }  // while

  for (i=0;i<=last;i++)
    delete Queue[i];

  if (found)
    return Distance[XExit][YExit];
  else
  { cout << "Floodfill did not reach the exit.\n";
    return DefaultDistance;
  }

}  // ComputeDistance

//************************************************************************

int main ()
{ int NInst, Inst;
  int x, y,
      dist;

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { 
    for (x=0;x<2*MaxDimension-1;x++)
      for (y=0;y<2*MaxDimension-1;y++)
        Maze[x][y] = UnknownRoom;
    XExit = UnknownCoordinate;
    YExit = UnknownCoordinate;

    DFS (MaxDimension-1, MaxDimension-1);

    if (XExit==UnknownCoordinate)
    { cout << DefaultDistance << EOL;
      fflush (NULL);
    }
    else
    { dist = ComputeDistance (MaxDimension-1, MaxDimension-1);
      cout << dist << EOL;
      fflush (NULL);
    }

  }  // for Inst

  return 0;

}

