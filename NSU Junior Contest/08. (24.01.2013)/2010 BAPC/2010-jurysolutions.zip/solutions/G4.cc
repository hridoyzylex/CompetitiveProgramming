
// Walter Kosters, snooker, 15.10.2010

#include <iostream>
using namespace std;

const int MAX = 1100;

int main ( ) {
  int cases, casenr, number, i;
  int p1, p2, remainingreds, remainingoppo;
  int Play[MAX];
  bool first, last;
  cin >> cases;
  for ( casenr = 0; casenr < cases; casenr++ ) {
    cin >> number;
    for ( i = 1; i <= number; i++ )
      cin >> Play[i];
    p1 = p2 = 0;
    last = first = true;
    remainingreds = 15;
    remainingoppo = 147;
    for ( i = 1; i <= number; i++ ) {
      if ( Play[i] == 1 ) {
        remainingreds--;
	remainingoppo -= 8;
      }//if
      else if ( remainingreds == 0 ) {
        if ( ! last ) {
          remainingoppo -= Play[i];
	}//if
	last = false;
      }//if
      if ( Play[i] == 0 )
        first = !first;
      if ( first ) {
        p1 += Play[i];
	if ( p1 - p2 > remainingoppo ) {
	  cout << i << endl;
	  i = number + 1;
	}//if
      }//if
      else {
        p2 += Play[i];
	if ( p2 - p1 > remainingoppo ) {
	  cout << i << endl;
	  i = number + 1;
	}//if
      }//else
    }//for
  }//for
  return 0;
}//main

