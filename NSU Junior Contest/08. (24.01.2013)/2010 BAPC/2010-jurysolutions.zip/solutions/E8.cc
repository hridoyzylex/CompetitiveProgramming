// Problem: Clocks
// Author: Rudy van Vliet
// Date: 21 October 2010

// Uses binary search to find the maximum clock that
// - either touches two clocks, fits on the wall and does not overlap
//   with other clocks,
// - or touches two adjacent boundaries of the wall, fits on the wall
//   and does not overlap with other clocks.
// This is the main case.
//
// The only other case is that a clock touches two opposite boundaries
// of the wall and stays between two existing clocks. In function
// DetermineMaximumClock, this is the case that is treated first.
//
// Time complexity: O(C^3 * log(...) ),
//   where the log comes from the binary search)
// Program seems to be correct.

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const int MaxW = 1000000;   // maximum width of wall
const int MaxH = 1000000;   // maximum height of wall
const int MaxC = 50;        // maximum number of clocks
const char EOL = '\n';
int X[MaxC+1],  // coordinates and radii of the clocks
    Y[MaxC+1],
    R[MaxC+1];
const double Tolerance = 0.0000005;  // 0.5 E-6

//****************************************************************************

bool CheckParameters (int W, int H, int C, int Inst)
 // Check values of parameters.
{ bool OK;

  OK = true;

  if ((W<1) || (W>MaxW))
  { cout << "incorrect value for W at instance " << Inst << ": "
          << W << EOL;
    OK = false;
  }

  if ((H<1) || (H>MaxH))
  { cout << "incorrect value for H at instance " << Inst << ": "
          << H << EOL;
    OK = false;
  }

  if ((C<0) || (C>MaxC))
  { cout << "incorrect value for C at instance " << Inst << ": "
          << C << EOL;
    OK = false;
  }

  return OK;

}  // CheckParameters

//****************************************************************************

double DoubleOfIntSquare (int x)
 // return square(x) as double
{ double doublex;

  doublex = x;
  return (doublex*doublex);

}  // DoubleOfIntSquare

//****************************************************************************

double DoubleSquare (double x)
 // returns square(x)
{
  return x*x;

}  // DoubleSquare

//****************************************************************************

bool CheckOverlappingClocks (int C, int Inst)
 // check if one or more clocks overlap
 // return: true, if no two clocks overlap
 //         false, if at least two clocks overlap
{ bool OK;
  int i, j;

  OK = true;

  for (i=1;i<C;i++)
    for (j=i+1;j<=C;j++)
    { if ( DoubleOfIntSquare (X[j] - X[i])
           + DoubleOfIntSquare (Y[j] - Y[i])
           < DoubleOfIntSquare (R[i] + R[j]) )
        // hope this does not suffer from rounding errors
      { cout << "Clocks " << i << " and " << j << " at instance " << Inst
             << " overlap.\n";
        OK = false;
      }
    }

  return OK;
  
}  // CheckOverlappingClocks

//****************************************************************************

double EuclidDistance (double x1, double y1, double x2, double y2)
 // Return Euclid distance between (x1,y1) and (x2,y2)
{ double dx, dy;

  dx = x2 - x1;
  dy = y2 - y1;

  return ( sqrt ( dx*dx + dy*dy ) );

}  // EuclidDistance

//****************************************************************************

double EuclidDistanceOfClocks (int i, int j)
 // Return Euclid distance between clock i and clock j
{
  return ( EuclidDistance ( (double) X[i], (double) Y[i],
                            (double) X[j], (double) Y[j] ) );

}  // EuclidDistanceOfClocks

//****************************************************************************

void IntSwap (int &x, int &y)
 // swap x and y
{ int tmp;

  tmp = x;
  x = y;
  y = tmp;

}  // IntSwap

//****************************************************************************

void DoubleSwap (double &x, double &y)
 // swap x and y
{ double tmp;

  tmp = x;
  x = y;
  y = tmp;

}  // DoubleSwap

//****************************************************************************

bool DetermineTouchingClocks1 (int W, int H, int i, double &r0,
                        double &x0, double &y0, double &x00, double &y00)
 // Determine positions (x0,y0) and (x00,y00) of two clocks of radius r0
 // that touch clock i and two opposite boundaries of the wall
{ int x1, y1, r1;
  double RootArg, Root;
  bool OK;

  x1 = X[i];
  y1 = Y[i];
  r1 = R[i];
  OK = true;

  if (H<=W)
  { y0 = 0.5 * H;
    y00 = 0.5 * H;
    r0 = 0.5 * H;

    RootArg = (r1+r0)*(r1+r0) - (y1-y0)*(y1-y0);
    if (RootArg < 0)
    { cout << "Unexpected root argument < 0 in DetermineTouchingClocks1.\n";
      OK = false;
    }
    else
    { Root = sqrt (RootArg);
      x0 = x1 + Root;
      x00 = x1 - Root;
    }
  }
  else  // H > W
  { x0 = 0.5 * W;
    x00 = 0.5 * W;
    r0 = 0.5 * W;

    RootArg = (r1+r0)*(r1+r0) - (x1-x0)*(x1-x0);
    if (RootArg < 0)
    { cout << "Unexpected root argument < 0 in DetermineTouchingClocks1.\n";
      OK = false;
    }
    else
    { Root = sqrt (RootArg);
      y0 = y1 + Root;
      y00 = y1 - Root;
    }
  }

  return OK;

}  // DetermineTouchingClocks1

//****************************************************************************

bool DetermineTouchingClocks2 (int i, int j, double r0,
              double &x0, double &y0, double &x00, double &y00)
 // Determine positions (x0,y0) and (x00,y00) of two clocks of radius r0
 // that touch clock i and clock j, if such clocks exist.
 // Return: true  if such clocks exist
 //         false if such clocks do not exist
 //                 (i.e., if clocks i and j are too far apart)
 // Pre: clock i and clock j are different clocks that do not overlap
{ int x1, y1, r1,
      x2, y2, r2;
  double C1, C2,
         C3, C4,
         ACo, BCo, CCo,  // coefficients of quadratic function in y0
         RootArg,        // argument of root function
         Root;
  bool xyswap;

  if (EuclidDistanceOfClocks (i, j) > R[i] + R[j] + 2*r0)
    return false;
  else  // clock i and clock j are not too far apart, so go for it
  {
    x1 = X[i];
    y1 = Y[i];
    x2 = X[j];
    y2 = Y[j];
    r1 = R[i];
    r2 = R[j];
    
    if (x1==x2)
    {  // we secretly interchange x and y,
       // so that one complex calculation suffices
      IntSwap (x1, y1);
      IntSwap (x2, y2);
      xyswap = true;
    }
    else
      xyswap = false;

      // now for sure x1 != x2

      // solve the following two equations:
      //   (x0 - x1)^2 + (y0 - y1)^2 = (r1 + r0)^2   (Eq A)
      //   (x0 - x2)^2 + (y0 - y2)^2 = (r2 + r0)^2   (Eq B)
    C1 = (r1 + r0) * (r1 + r0);
    C2 = (r2 + r0) * (r2 + r0);

      // subtract (Eq B) from (Eq A);
      // then express x0 in terms of y0: x0 = C3 + C4*y0
    C3 = (C1 - C2 - DoubleOfIntSquare (x1) + DoubleOfIntSquare (x2)
                  - DoubleOfIntSquare (y1) + DoubleOfIntSquare (y2) ) /
            ( -2*(x1-x2) );
    C4 = ((double) (- (y1-y2) ) ) / (x1-x2);

      // substitute expression for x0 in (Eq A),
      // which yields a quadratic equation in (just) y0:
      //   ACo * y0^2 + BCo * y0 + CCo = 0
    ACo = C4 * C4 + 1;
    BCo = 2 * C3 * C4 - 2 * x1 * C4 - 2*y1;
    CCo = C3 * C3 - 2 * x1 * C3
            + DoubleOfIntSquare (x1) + DoubleOfIntSquare (y1) - C1;

    RootArg = BCo * BCo - 4 * ACo * CCo;
    if (RootArg < 0)
    { cout << "Unexpected root argument < 0.\n";
      return false;
    }
    else
    {
      Root = sqrt (RootArg);
      y0 = (- BCo + Root) / ( 2 * ACo );
      x0 = C3 + C4 * y0;
      y00 = (- BCo - Root) / ( 2 * ACo );
      x00 = C3 + C4 * y00;

      if (xyswap)
      { DoubleSwap (x0, y0);
        DoubleSwap (x00, y00);
      }

//      cout << "(" << x0 << "," << y0 << ") " << r0 << EOL;
//      cout << "(" << x00 << "," << y00 << ") " << r0 << EOL;

      return true;
    }  // RootArg >= 0

  }  // clock i and clock j are not too far apart

}  // DetermineTouchingClocks2

//****************************************************************************

bool CheckNewClock (int W, int H, int C, double x0, double y0, double r0)
  // Check if new clock at (x0,y0) with radius r0 stays within the dimensions
  // of the wall and does not overlap with other clocks.
{ bool OK;
  int k;

  OK = true;

  if ( (x0-r0 < 0-Tolerance) || (x0+r0 > W+Tolerance)
       || (y0-r0 < 0-Tolerance) || (y0+r0 > H+Tolerance))
    OK = false;

  for (k=1;(k<=C) && OK;k++)
    if (EuclidDistance ( (double) X[k], (double) Y[k], x0, y0 )
           < R[k]+r0-Tolerance)
        OK = false;

  return OK;

}  // CheckNewClock

//****************************************************************************

double DetermineMaximumClock (int W, int H, int C)
  // Determine maximum clocksize that can be added to the wall.
  // Use binary search on the clocksize. For each value, examine all
  // possible combinations of clocks and/or walls that may touch a clock
  // of this size.
{ double lowerbound,  // radius of a clock we have found to be addable
         upperbound,  // radius of a clock we have found to be not addable
         mid, r0,
         x0, y0,
         x00, y00;
  int  i, j;
  bool addable,
       touch;

  addable = false;

    // try to position a clock between two opposite boundaries of the wall
    // and touching one clock
  for (i=1;(i<=C) && !addable;i++)
  { touch = DetermineTouchingClocks1 (W, H, i, r0, x0, y0, x00, y00);

    if (touch)
    { // check if clocks stay within the dimensions of the wall
      // and if they do not overlap with other clocks
      if ( (CheckNewClock (W, H, C, x0, y0, r0)) ||
           (CheckNewClock (W, H, C, x00, y0, r0)) )
        addable = true;
    }
  }  // for i

  if (addable)
    return r0;
  else
  {
      // start the binary search
    lowerbound = 0.0;
    if (H<=W)
      upperbound = 0.5 * (H + 0.01);  // this value (for the radius of a clock)
                                      // is certainly not possible
    else
      upperbound = 0.5 * (W + 0.01);

    while (upperbound - lowerbound > Tolerance)
    { mid = (lowerbound + upperbound) / 2;

      addable = false;

      for (i=1;(i<C) && !addable;i++)
        for (j=i+1;(j<=C) && !addable;j++)
        {
          // try to position a clock of size mid,
          // such that it touches clock i and clock j
          touch = DetermineTouchingClocks2 (i, j, mid, x0, y0, x00, y00);
          if (touch)
          {  // check if clocks stay within the dimensions of the wall
             // and if they do not overlap with other clocks

            if ( (CheckNewClock (W, H, C, x0, y0, mid)) ||
                 (CheckNewClock (W, H, C, x00, y00, mid)) )
              addable = true;

          }
        }  // for j

      if (!addable)
      {  // try to position a clock of size mid in a corner of the wall
        x0 = mid;
        y0 = mid;
        if (CheckNewClock (W, H, C, x0, y0, mid))
          addable = true;

        if (!addable)
        { x0 = mid;
          y0 = H - mid;
          if (CheckNewClock (W, H, C, x0, y0, mid))
            addable = true;
        }

        if (!addable)
        { x0 = W - mid;
          y0 = mid;
          if (CheckNewClock (W, H, C, x0, y0, mid))
            addable = true;
        }

        if (!addable)
        { x0 = W - mid;
          y0 = H - mid;
          if (CheckNewClock (W, H, C, x0, y0, mid))
            addable = true;
        }
      }

      if (addable)
        lowerbound = mid;
      else
        upperbound = mid;

    }  // while

    return lowerbound;

  }  // not addable between two opposite boundaries of the wall and touching
     // one clock

}  // DetermineMaximumClock

//****************************************************************************

int main ()
{ int NInst, Inst;
  int W, H,
      C,
      i;
  bool OK;
  double MaxClock;

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { cin >> W >> H;
    cin >> C;

    OK = CheckParameters (W, H, C, Inst);

    for (i=1;i<=C;i++)
    {   // continue reading input, even if some value was not OK
      cin >> X[i] >> Y[i] >> R[i];

      if ( (R[i]<=0) || (X[i] - R[i] < 0) || (X[i] + R[i] > W)
                     || (Y[i] - R[i] < 0) || (Y[i] + R[i] > H) )
      { cout << "incorrect values for x, y or r of clock " << i
             << " at instance " << Inst << ": (" << X[i] << "," << Y[i]
             << ") " << R[i] << EOL;
        OK = false;
      }
    }

    if (OK)
      OK = CheckOverlappingClocks (C, Inst);

    if (OK)
    { MaxClock = DetermineMaximumClock (W, H, C);
      cout << setiosflags (ios::fixed) << setprecision (9) << MaxClock << EOL;
    }

  }  // for Inst
  
  return 0;

}
