
//
// Collatz, Walter Kosters, 18.10.2010
//

#include <iostream>
using namespace std;

int main ( ) {
  int cases, casenr, N;
  cin >> cases;
  for ( casenr = 0; casenr < cases; casenr++ ) {
    cin >> N;
    if ( N % 2 == 0 )
      cout << ( N + 1 ) / 2 + ( N + 1 ) / 3 << endl;
    else
      cout << ( N + 1 ) / 2 + ( N + 3 ) / 3 << endl;
  }//for
  return 0;
}//main

