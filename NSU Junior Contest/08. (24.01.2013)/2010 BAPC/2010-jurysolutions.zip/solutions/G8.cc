// Problem: Snooker
// Author: Rudy van Vliet
// Date: 25 August 2010

// Extended and corrected version of `snooker_ft.cc'
// * function abs added
// * function checkPoints added
// * check on value of n added
// * check on early ending added
// * fin replaced by cin
// * variable `remaining' updated correctly
// * variable `remaining2' introduced for correctness

#include<iostream>
#include<fstream>
using namespace std;

int abs (int x)
{
  if (x>=0)
    return x;
  else
    return -x;

}  // abs

bool checkPoints (int i, int points, int previous, int reds, int remaining,
                  int score0, int score1)
 // check if value of `points' is consistent with earlier values
{ bool OK;
  int p, sum;

  OK = true;

  if ((points<0) || (points>7))
  { OK = false;
    cout << "Value must be between 0 and 7 (inclusive).\n";
  }

  if ((i==1) && (points>1))
  { OK = false;
    cout << "We must start the sequence with 1 (or 0).\n";
  }

  if ((i>1) && (previous==1) && (points==1))
  { OK = false;
    cout << "A red ball cannot be followed by another red ball.\n";
  }

  if ((i>1) && (previous!=1) && (reds>0) && (points>1))
  { OK = false;
    cout << "Initially, non-red balls can only be potted right after a red ball.\n";
  }

  if ((reds==0) && (points==1))
  { OK = false;
    cout << "When there are no more red balls on the table, we cannot pot one.\n";
  }

  if ((reds==0) && (previous!=1) && (points>=2) && (points<=6))
  { p = points;
    sum = 0;
    while (p<=7)
    { sum += p;
      p ++;
    }

    if (sum != remaining)
    { OK = false;
      cout << "Non-red balls must be potted in increasing order.\n";
    }
  }

  if ((reds==0) && (previous!=1) && (points==7))
  { if ((remaining!=7) && (remaining!=0))
       // remaining==0 is possible, when players have equal scores
       // when the table is empty for the first time
    { OK = false;
      cout << "Black ball must be potted at the end.\n";
    }
  }
    
    // final check, is independent of value of points as such
  if ((remaining==0) && (score0!=score1))
  { OK = false;
    cout << "Game must not continue once it has reached the end.\n";
  }

  return OK;

}  // checkPoints

int main() {
    
    const int startingreds = 15;
    const int maxscore = startingreds*1+startingreds*7+2+3+4+5+6+7; // 147

    
    int m, n, i, points, previous, decided, turn, remaining, reds, score[2];
    int remaining2, difference;
    
    cin >> m;
    
    while(m--) {
        remaining = maxscore;
        reds = startingreds;
        decided = turn = previous = score[0] = score[1] = 0;
        cin >> n;        
        if ((n<36) || (n>1000))
          cout << "Value of n must be between 36 and 1000 (inclusive).\n";
        for(i=1; i<=n; i++) {
            previous = points;
            cin >> points;    
            checkPoints (i, points, previous, reds, remaining,
                         score[0], score[1]);
            if(points == 0) {
                turn = (turn + 1) % 2;
                if(previous == 1)
                    remaining -= 7;
            } // if
            else {
                score[turn] += points;
                if(points == 1) {
                    remaining--;
                    reds--;
                } // if
                else {
                    if(previous == 1)
                        remaining -= 7;
                    else
                        remaining -= points;
                } // else
            } // else

            if (decided==0)
            { if(abs(score[0] - score[1]) > remaining)
                decided = i;
              else  // abs is not large enough for decision,
                    // but remaining may actually be different for player
                    // who did not pot the current ball (if this ball
                    // is red).
              { if (points==1)  // a red ball has been potted
                { remaining2 = remaining - 7;  // the other player cannot
                                               // score these 7 points
                  if (turn==0)
                    difference = score[0] - score[1];
                  else
                    difference = score[1] - score[0];
                  if (difference > remaining2)
                    decided = i;
                }
              }  // else: abs is not large enough for decision
            }  // decided == 0

//            cerr << i << ". " << points << "p: " << score[0] << " - " 
//                 << score[1] << ", remaining: " << remaining << endl;
        } // for
        if ((remaining>0)
            || ((remaining==0) && (score[0]==score[1])) )
          cout << "Game has ended before it reached the end.\n";
        cout << decided << endl;
    } // while
    
    return 0;
} // main
