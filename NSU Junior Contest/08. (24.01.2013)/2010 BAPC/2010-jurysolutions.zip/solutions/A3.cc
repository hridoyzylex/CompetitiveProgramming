//
// GENESHUFFLE_HJH
//
#include <iostream>
using namespace std;

const 
  int MaxN = 1000000;

  int a[MaxN], b[MaxN], a_inv[MaxN], b_inv[MaxN];

int main ()
{
  int Inst,NInst;
  int Len,i;
  int x, start, last;

  cin >> NInst;

  for ( Inst=1; Inst<=NInst; Inst++ )
  {
//    cout << "   | CASE " << Inst << endl;
    cin >> Len;
    for ( i=1;i<=Len;i++ ) { cin >> x; a[i] = x; a_inv[x] = i; }
    for ( i=1;i<=Len;i++ ) { cin >> x; b[i] = x; b_inv[x] = i; }
    
//    cout << "   | ";
//    for ( i=1;i<=Len;i++ ) { cout << a[i] << " " ; } 
//    cout << endl;
//    cout << "   | ";
//    for ( i=1;i<=Len;i++ ) { cout << b[i] << " " ; } 
//    cout << endl;
    
    for ( last=1; last<=Len; last++ )
    { start=last;
      for  ( i=start; i<=last; i++ )
      {
        x = a[i]; if (b_inv[x] > last) last = b_inv[x];
        x = b[i]; if (a_inv[x] > last) last = a_inv[x];
      }
      if (start>1) cout << " ";
      cout << start << "-" << last  ;
    }
    cout << endl;
  }
 
}
