/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXL 1000000
char line[MAXL+10];
char ret[MAXL+10];

int main() {
	int t, i, j, position, length;
	scanf("%d\n", &t);
	while(t--) {
		scanf("%s\n", line);
		position = 0;
		length = 0;
		ret[0] = 0;
		for(i = 0; line[i]; i++) {
			if(line[i] == '-') {
				if(position > 0) {
					for(j = position; j <= length; j++)
						ret[j-1] = ret[j];
					position--;
                                        length --;
				}
			} else if(line[i] == '<') {
				if(position > 0) {
					position--;
				}
			} else if(line[i] == '>') {
				if(position < length) {
					position++;
				}
			} else {
				for(j = length; j >= position; j--)
					ret[j+1] = ret[j];
				ret[position] = line[i];
				length++;
				position++;
			}
		}
		printf("%s\n", ret);
	}

  return 0;
}
