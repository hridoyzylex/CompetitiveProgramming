//Johan de Ruiter

#include <iostream>  
#include <sstream>  
#include <string>  
#include <vector>  
#include <queue>  
#include <set>  
#include <map>  
#include <cstdio>  
#include <cstdlib>  
#include <cctype>  
#include <cmath>  
#include <list>  
#include <numeric> 
#include <ctime>
#include <algorithm>
#include <cstring>
using namespace std;  
  
typedef vector<int> vi;  
typedef vector<vi> vvi;  
typedef vector<string> vs;  
typedef vector<vs> vvs; 
#define pb push_back  
#define sz(v) ((int)(v).size()) 


int main()
{
  int runs,run,i,j,k;
  scanf("%d",&runs);
  for(run=0;run<runs;run++)
  {
    int score[2]={0,0};
    int colouredinplay=2+3+4+5+6+7;
    int redballsleft=15;
    int turn=0;
 
    int inballs,ball;   
    scanf("%d",&inballs);
    int handled=0;
    bool decided=false;
    do
    {
      ball=99; int now=0;
      int previous=-1;
      while(ball&&handled<inballs)
      {
        scanf("%d",&ball); handled++;
        score[turn]+=ball; now++;

        if(ball==1) redballsleft--;
        
        if(ball!=1&&previous!=1) colouredinplay-=ball;

        int igetmax=score[turn]+colouredinplay+redballsleft*8;
        int ugetmax=score[1-turn]+colouredinplay+redballsleft*8;

        if(ball==1) igetmax+=7;
        
        if(igetmax<score[1-turn]||
           ugetmax<score[turn])
        {
          printf("%d\n",handled);
          decided=true;
          break; 
        }
        previous=ball;
      }
      
      turn=1-turn;
    } while(!decided);   
    
    while(handled<inballs)
    { scanf("%d",&ball); handled++; }
  }
  return 0;
}
