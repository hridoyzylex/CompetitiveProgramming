
//
// Maze, Walter Kosters, 13.10.2010
//

#include <iostream>
#include <string>
using namespace std;

const unsigned int MAX = 210;
int themaze[MAX][MAX];
bool visited[MAX][MAX];
bool vertwalls[MAX][MAX];
bool horwalls[MAX][MAX];
unsigned int targetx, targety;

void number (int x, int y) {
  unsigned int i, j;
  if (x==targetx && y==targety)
    return;
  visited[x][y] = true;
  while ( true ) {
    for ( i = 0; i < MAX; i++ )
      for ( j = 0; j < MAX; j++ ) {
        if ( visited[i][j] ) {
          if ( horwalls[i-1][j] && !visited[i-1][j] ) {
	    visited[i-1][j] = true;
            themaze[i-1][j] = themaze[i][j]+1;
	    if ( i-1 == targetx && j == targety )
	      return;
          }//if
          if ( horwalls[i][j] && !visited[i+1][j] ) {
	    visited[i+1][j] = true;
            themaze[i+1][j] = themaze[i][j]+1;
	    if ( i+1 == targetx && j == targety )
	      return;
          }//if
          if ( vertwalls[i][j-1] && !visited[i][j-1] ) {
	    visited[i][j-1] = true;
            themaze[i][j-1] = themaze[i][j]+1;
	    if ( i == targetx && j-1 == targety )
	      return;
          }//if
          if ( vertwalls[i][j] && !visited[i][j+1] ) {
	    visited[i][j+1] = true;
            themaze[i][j+1] = themaze[i][j]+1;
	    if ( i == targetx && j+1 == targety )
	      return;
          }//if
	}//if
      }//for
  }//while
}//number

void visit (int x, int y) {
  string theline;
  unsigned int i;
  cin >> theline;
  if ( ! ( visited[x][y] ) ) { // new square
    visited[x][y] = true; // mark it
    for ( i = 0; i < theline.length ( ); i++ ) {
      switch ( theline[i] ) {
        case 'N':
	  horwalls[x-1][y] = true;
          if (!visited[x-1][y]){
	  cout << 'N' << endl; fflush(NULL);
          visit (x-1,y);
	  cout << 'S' << endl; fflush(NULL);
	  visit (x,y);
          }
	  break;
	case 'E':
	  vertwalls[x][y] = true;
          if (!visited[x][y+1]){
	  cout << 'E' << endl; fflush(NULL);
          visit (x,y+1);
	  cout << 'W' << endl; fflush(NULL);
	  visit (x,y);
          }
	  break;
	case 'W':
	  vertwalls[x][y-1] = true;
          if (!visited[x][y-1]){
	  cout << 'W' << endl; fflush(NULL);
          visit (x,y-1);
	  cout << 'E' << endl; fflush(NULL);
	  visit (x,y);
          }
	  break;
	case 'S':
	  horwalls[x][y] = true;
          if (!visited[x+1][y]){
	  cout << 'S' << endl; fflush(NULL);
          visit (x+1,y);
	  cout << 'N' << endl; fflush(NULL);
	  visit (x,y);
          }
	  break;
	case '*':
	  targetx = x;
	  targety = y;
	  break;
      }//switch
    }//for
  }//if
}//visit

int main ( ) {
  int cases, casenr;
  unsigned int i, j;
  int x, y;
  int theanswer;
  string theline;
  cin >> cases;
  for ( casenr = 0; casenr < cases; casenr++ ) {
    for ( i = 0; i < MAX; i++ )
      for ( j = 0; j < MAX; j++ ) {
        horwalls[i][j] = vertwalls[i][j] = visited[i][j] = false;
      }//for
    x = y = 105;
    targetx = targety = 0;
    visit (x,y);

    for ( i = 0; i < MAX; i++ )
      for ( j = 0; j < MAX; j++ ) {
	themaze[i][j] = 0;
	visited[i][j] = false;
      }//for
    theanswer = -1;
    if ( targetx == 0 && targety == 0 ) {
      cout << theanswer << endl; fflush(NULL);
    }//if
    else {
      number (x,y);
      cout << themaze[targetx][targety] << endl; fflush(NULL);
    }//else
  }//for
  return 0;
}//main

