/*
 * BAPC 2010
 * Jeroen Bransen
 */

import java.util.*;
import java.io.*;

public class mazerecognition_jb_java {
   public static int MAX_W = 100;
   public static int MAX_H = 100;
   public static BufferedReader in;
   public static boolean[][][] door;
   public static boolean[][] done;
   public static String dirs = "NEWS";
   public static int[] dx = {0, 1, -1, 0};
   public static int[] dy = {1, 0, 0, -1};
   public static int eX, eY;
   
   public static void main(String[] args) throws Exception {
      in = new BufferedReader(new InputStreamReader(System.in));
      
      int nTests = Integer.parseInt(in.readLine());
      for(int test = 0; test < nTests; test++) {
         door = new boolean[4][MAX_W*2+10][MAX_H*2+10];
         done = new boolean[MAX_W*2+10][MAX_H*2+10];
         eX = -1; eY = -1;
         dfs(MAX_W+5, MAX_H+5);
         if(eX == -1 || eY == -1)
            System.out.println("-1");
         else
            System.out.println(findAnswer());
      }
   }
   
   public static int findAnswer() {
      Queue<State> Q = new LinkedList<State>();
      Q.add(new State(MAX_W+5, MAX_H+5, 0));
      done = new boolean[MAX_W*2+10][MAX_H*2+10];
      while(!Q.isEmpty()) {
         State top = Q.poll();
         if(done[top.x][top.y]) continue;
         done[top.x][top.y] = true;
         if(top.x == eX && top.y == eY) return top.s;
         for(int i = 0; i < 4; i++) {
            if(door[i][top.x][top.y]) {
               Q.add(new State(top.x+dx[i], top.y+dy[i], top.s+1));
            }
         }
      }
      return -1;
   }
   
   public static void dfs(int x, int y) throws Exception {
      String line = in.readLine();
      done[x][y] = true;
      for(int i = 0; i < line.length(); i++) {
         if(line.charAt(i) == '*') {
            eX = x;
            eY = y;
         } else {
            int dir = dirs.indexOf(line.charAt(i));
            door[dir][x][y] = true;
            if(!done[x+dx[dir]][y+dy[dir]]) {
               System.out.println(dirs.charAt(dir));
               dfs(x+dx[dir], y+dy[dir]);
               System.out.println(dirs.charAt(3-dir));
               in.readLine();
            }
         }
      }
   }
   
   static class State {
      public int x, y, s;
      
      public State(int x, int y, int s) {
         this.x = x;
         this.y = y;
         this.s = s;
      }
   }
}
