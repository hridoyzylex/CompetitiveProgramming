//Solution to Gene Shuffle 
//by Johan de Ruiter

#include <iostream>  
#include <sstream>  
#include <string>  
#include <vector>  
#include <queue>  
#include <set>  
#include <map>  
#include <cstdio>  
#include <cstdlib>  
#include <cctype>  
#include <cmath>  
#include <list>  
#include <numeric> 
#include <ctime>
#include <algorithm>
#include <cstring>
using namespace std;  
  
typedef vector<int> vi;  
typedef vector<vi> vvi;  
typedef vector<string> vs;  
typedef vector<vs> vvs; 
#define pb push_back  
#define sz(v) ((int)(v).size()) 

int main()
{
  int runs,run,j,N;
  bool saw1[100001],saw2[100001];
  int list1[100000],list2[100000];

  scanf("%d",&runs);
  for(run=0;run<runs;run++)
  {
    memset(saw1,0,sizeof(saw1));
    memset(saw2,0,sizeof(saw2));

    scanf("%d",&N);
    for(j=0;j<N;j++) scanf("%d",&list1[j]);
    for(j=0;j<N;j++) scanf("%d",&list2[j]);

    int unequal=0,last=0;
    for(j=0;j<N;j++)
    {
      unequal+=saw2[list1[j]]?-1:1;
      saw1[list1[j]]=true;
      unequal+=saw1[list2[j]]?-1:1;
      saw2[list2[j]]=true;      
      
      if(unequal==0)
      {
        if(last) printf(" ");
        printf("%d-%d",last+1,j+1);
        last=j+1;
      }
    }
    printf("\n");
  }  
  
  return 0;
}

