/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define MAXC 50

int x[MAXC+1], y[MAXC+1], r[MAXC+1];
int h, w, c;

double dist(double x1, double y1, double x2, double y2) {
	double dx = x1 - x2, dy = y1 - y2;
	return sqrt(dx * dx + dy * dy);
}

double sqr(double a) {
	return a * a;
}

// Check if this new clock fits here, i and j give indices
// of the clocks it touches (to make sure we don't check
// and return false due to rounding errors)
bool fit(double nx, double ny, double nr, int i, int j, bool print) {
	int k;
	if(nx - nr < 0 || ny - nr < 0 || nx + nr > w || ny + nr > h)
		return false;
	for(k = 0; k < c; k++)
		if(k != i && k != j && dist(x[k], y[k], nx, ny) < nr+r[k])
			return false;
	if(print)
		fprintf(stderr, "X = %lf; Y = %lf; R = %lf\n", nx, ny, nr);
	return true;
}

// Check whether we can fit a clock with radius nr on the wall
bool check(double nr, bool print) {
	int i, j;
	double dx, dy, d, a, x3, y3, g, r1, r2, rx, ry;
	// New clock touching 2 existing clocks
	for(i = 0; i < c; i++) {
		for(j = i + 1; j < c; j++) {
			// We want to construct a circle with radius nr touching
			// clock i and j. This is equivalent to finding the intersection
			// of 2 circles centered at x[i], y[i] and x[j], y[j] with radius
			// r1 and r2 respectivally.
			r1 = r[i] + nr;
			r2 = r[j] + nr;
			dx = x[j] - x[i];
			dy = y[j] - y[i];
			d = sqrt(dx * dx + dy * dy);
			if (d > r1 + r2)
				continue;
			a = ((r1 * r1) - (r2 * r2) + (d * d)) / (2 * d);
			x3 = x[i] + (dx * a / d);
			y3 = y[i] + (dy * a / d);
			g = sqrt((r1 * r1) - (a * a));
			rx = -dy * (g / d);
			ry = dx * (g / d);
			if(fit(x3+rx,y3+ry,nr,i,j,print) || fit(x3-rx,y3-ry,nr,i,j,print))
				return true;
		}
		// New clock touching a wall and an existing clock
		if(x[i] - r[i] <= nr*2 && fit(nr, y[i] + sqrt(sqr(nr + r[i]) - sqr(x[i] - nr)), nr, i, -1,print))
			return true;
		if(x[i] - r[i] <= nr*2 && fit(nr, y[i] - sqrt(sqr(nr + r[i]) - sqr(x[i] - nr)), nr, i, -1,print))
			return true;
		if(y[i] - r[i] <= nr*2  && fit(x[i] + sqrt(sqr(nr + r[i]) - sqr(y[i] - nr)), nr, nr, i, -1,print))
			return true;
		if(y[i] - r[i] <= nr*2  && fit(x[i] - sqrt(sqr(nr + r[i]) - sqr(y[i] - nr)), nr, nr, i, -1,print))
			return true;
		if(x[i] + r[i] >= w - nr*2 && fit(w - nr, y[i] + sqrt(sqr(nr + r[i]) - sqr(w - nr - x[i])), nr, i, -1,print))
			return true;
		if(x[i] + r[i] >= w - nr*2 && fit(w - nr, y[i] - sqrt(sqr(nr + r[i]) - sqr(w - nr - x[i])), nr, i, -1,print))
			return true;
		if(y[i] + r[i] >= h - nr*2 && fit(x[i] + sqrt(sqr(nr + r[i]) - sqr(h - nr - y[i])), h - nr, nr, i, -1,print))
			return true;
		if(y[i] + r[i] >= h - nr*2 && fit(x[i] - sqrt(sqr(nr + r[i]) - sqr(h - nr - y[i])), h - nr, nr, i, -1,print))
			return true;
	}
	// New clock touching 2 walls
	if(fit(nr, nr, nr, -1, -1,print) || fit(w-nr, nr, nr, -1, -1,print) || fit(nr, h-nr, nr, -1, -1,print) || fit(w-nr, h-nr, nr, -1, -1,print))
		return true;
	return false;
}

int main() {
	int t, i;
	double low, high, act;
	scanf("%d\n", &t);
	while(t--) {
		scanf("%d %d\n", &w, &h);
		scanf("%d\n", &c);
		for(i = 0; i < c; i++)
			scanf("%d %d %d\n", &x[i], &y[i], &r[i]);

		// Binary search on the radius of the new clock
		low = 0;
		high = w;
		for(i = 0; i < 100; i++) {
			act = (low + high) / 2;
			if(check(act, false))
				low = act;
			else
				high = act;
		}
		check(low, true); // print location
		printf("%.10lf\n", low);
	}
	return 0;
}
