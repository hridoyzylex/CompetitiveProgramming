// Problem: Pie division
// Author: Rudy van Vliet
// Date: 15 June 2010
// Variable stepsback introduced, 22 October 2010

// Program seems to work well.
// About 100 lines of this code are just for implementation of MergeSort
// (this can probably be simplified).
// About 200 lines of this code (function CheckDivisions) describe the real
// algorithm.

#include <iostream>
using namespace std;

const int MaxN = 1000;
const char EOL = '\n';
int x[2*MaxN+1],
    y[2*MaxN+1];
bool firsttype[2*MaxN+1];
int tmpx[2*MaxN+1],
    tmpy[2*MaxN+1];
bool tmpfirsttype[2*MaxN+1];

//****************************************************************************

void CopyToTmp (int i12, int i)
  // copy the data of the piece at position i12 to tmp position i
{
  tmpx[i] = x[i12];
  tmpy[i] = y[i12];
  tmpfirsttype[i] = firsttype[i12];
  
}  // CopyToTmp

//****************************************************************************

void CopyFromTmp (int i12, int i)
  // copy the data of the piece at tmp position i to position i12
{
  x[i12] = tmpx[i];
  y[i12] = tmpy[i];
  firsttype[i12] = tmpfirsttype[i];
  
}  // CopyFromTmp

//****************************************************************************

void Merge (int mini, int mid, int maxi)
  // merge the two subsequences at positions mini...mid and mid+1..maxi
  // pre: 1 <= mini <= mid < maxi <= 2*N
{ int i,
      i1, i2,
      j;

  i = 1;
  i1 = mini;
  i2 = mid+1;
  while ((i1<=mid) && (i2<=maxi))
  {
    if (x[i1]<=x[i2])
    { CopyToTmp (i1, i);
      i1 ++;
    }
    else
    { CopyToTmp (i2, i);
      i2 ++;
    }
    i ++;
  }

  if (i1>mid)
    // copy remaining pieces from second subsequence
  { while (i2<=maxi)
    { CopyToTmp (i2, i);
      i2 ++;
      i ++;
    }
  }
  else
    // copy remaining pieces from first subsequence
  { while (i1<=mid)
    { CopyToTmp (i1, i);
      i1 ++;
      i ++;
    }
  }

    // copy tmp sequence to original positions
  i = 1;
  j = mini;
  while (j<=maxi)
  { CopyFromTmp (j, i);
    i ++;
    j ++;
  }

}  // Merge

//****************************************************************************

void Sort (int mini, int maxi)
  // sort the pieces of pie at positions mini..maxi (using MergeSort)
  // pre: 1 <= mini <= maxi <= 2*N
{ int mid;

  if (maxi>mini)
  { mid = (mini+maxi)/2;
    Sort (mini, mid);
    Sort (mid+1, maxi);
    Merge (mini, mid, maxi);
  }

}  // Sort

//****************************************************************************

void SortOnX (int N)
  // sort the pieces of pie by their x-coordinate (in increasing order)
  //   (using MergeSort)
  // pre: N >= 1
{ int mini, maxi, mid;

  mini = 1;
  maxi = 2*N;
  mid = (mini+maxi)/2;
  Sort (mini, mid);
  Sort (mid+1, maxi);
  Merge (mini, mid, maxi);
 
}

//****************************************************************************

void PrintPieces (int N)
{ int i;

  for (i=1;i<=2*N;i++)
    cout << x[i] << ' ' << y[i] << ' ' << firsttype[i] << EOL;

}  // PrintPieces

//****************************************************************************

void PrintLine (int basex, int basey, int dx, int dy)
{
  cout << "Line at base (" << basex << "," << basey << ") and with direction ("
       << dx << "," << dy << ")\n";

}  // PrintLine

//****************************************************************************

void Switch (int i, int j)
  // switch pieces of pie at positions i and j
{ int tmpint;
  bool tmpbool;

  tmpint = x[i];
  x[i] = x[j];
  x[j] = tmpint;

  tmpint = y[i];
  y[i] = y[j];
  y[j] = tmpint;

  tmpbool = firsttype[i];
  firsttype[i] = firsttype[j];
  firsttype[j] = tmpbool;
 
}  // Switch

//****************************************************************************

void CheckDivisions (int N)
{ int gooddivisionscounter,  // counts the good divisions
      omit1, omit2,  // positions of pieces of pie that are not considered
                     // in determining minimum angle
      dx, dy, basei, basex, basey,  // specify dividing line
      firstpiecounter,  // number of pies of first type to the left
                        // of dividing line
      i,
      mini,  // i with minimum angle so far
      mintype,  // special code: 0 - no minimum angle yet
                //               1 - minimum angle between 0.5 pi and pi
                //               2 - minimum angle of 0.5 pi (perpendicular
                //                   to dividing line
                //               3 - minimum angle between 0 and 0.5 pi
      numer_lambda,  // numerator of lambda
      numer_mu,      // numerator of mu
      nrotherthanorig;  // number of pieces of pie that have moved to
            // other side of dividing line, as compared to original division
  bool totheright,  // indicates whether or not pie at minimum angle is
                    // to the right of dividing line
       origleft[2*MaxN+1],  // indicates wether or not pie at position i
                            // was to the left of original dividing line
                            // (in fact redundant, because this is true,
                            // if and only if i<=N)
       backtoorigdivision;  // we have obtained new division, which is
                            // equal to original division
  double ratio, minratio;  // tangent of angle / minimum angle
  int stepsback, maxstepsback;  // (max) number of times we found the same 
                            // dividing line (we step back with (basex, basey))

  gooddivisionscounter = 0;

  // first division: by vertical line at `median' of x-coordinates,
  // i.e., just to the right of piece at position N

  omit2 = 0;

  // special case: two pieces in the middle with same x-coordinate
  // the upper one is considered to be left of the lower one
  if (x[N]==x[N+1])
  { omit2 = N+1;
    if (y[N]<y[N+1])
      Switch (N, N+1);
  }

  // special case: two pieces just to the left of the middle with
  // same x-coordinate;
  // also in this case, the upper one is considered to be left of
  // the lower one
  if (x[N-1]==x[N])
  { omit2 = N-1;
    if (y[N-1]<y[N])
      Switch (N-1, N);
  }

  omit1 = N;

    // specify the (vertical) dividing line
  dx = 0;
  dy = 1;
  basei = N;
  basex = x[N];
  basey = y[N];

  firstpiecounter = 0;  // counts the number of pies of first type
                        // to the left of dividing line
  for (i=1;i<=N;i++)
  { if (firsttype[i])
      firstpiecounter ++;
    origleft[i] = true;
  }
  for (i=N+1;i<=2*N;i++)
    origleft[i] = false;

  nrotherthanorig = 0;
  backtoorigdivision = false;

  maxstepsback = 0;
  stepsback = 0;

  // we do not check this division;
  // it will be checked in final iteration of while-loop

  while (! backtoorigdivision)
  {
//    cout << "new iteration with following line\n";
//    PrintLine (basex, basey, dx, dy);

    // rotate dividing line, until you encounter a pie;
    // in other words: determine pie at minimum angle
    mini = 0;
    mintype = 0;  // no minimum yet;
    for (i=1;i<=2*N;i++)
    {
      if ((i!=omit1) && (i!=omit2))
      {  // determine tangent/angle
         // first, determine (lambda, mu) such that
         //   (x[i],y[i]) = (basex, basey) + lambda (dx, dy) + mu (dy, -dx)
         //   mu > 0  implies that (x[i],y[i]) is to the right of dividing line
        numer_lambda = dy*(y[i] - basey) + dx*(x[i]-basex);
          // the denominator = (dy*dy + dx*dx)
        numer_mu = - dx*(y[i] - basey) + dy*(x[i]-basex);
          // the denominator = (dy*dy + dx*dx)

//        cout << "i=" << i << " and (lambda,mu) = (" << numer_lambda
//             << "," << numer_mu << ")\n";

        if (numer_mu==0)  // this is not supposed to occur
        { cout << "Pie at position " << i << " is also at following line\n";
          PrintLine (basex, basey, dx, dy);
        }
        else  // numer_mu != 0
        { if (numer_lambda==0)  // perpendicular to dividing line
          { if ((mintype==0) || (mintype==1))
            { mini = i;
              mintype = 2;  // perpendicular
              totheright = (numer_mu>0);
            }
            // else: not a new minimum angle
          }
          else  // numer_lambda != 0, either
          { ratio = ((double) numer_mu) / numer_lambda;  // tangent of alpha
            if (ratio > 0)  // angle between 0 and 0.5 pi
            { if ( (mintype==0) || (mintype==1) || (mintype==2) ||
                   ((mintype==3) && (ratio < minratio)) )
              { mini = i;
                mintype = 3;  // angle < 0.5 pi
                minratio = ratio;
                totheright = (numer_mu>0);
              }
              // else: not a new minimum angle
            }
            else  // ratio < 0, so angle between 0.5 pi and pi
            { if ( (mintype==0) || ((mintype==1) && (ratio < minratio)) )
                  // (ratio < minratio) means that ratio is more negative,
                  // hence, angle is closer to 0.5 pi
              { mini = i;
                mintype = 1;  // angle between 0.5 pi and pi
                minratio = ratio;
                totheright = (numer_mu>0);
              }
            }  // ratio < 0
          }  // numer_lambda != 0
        }  // numer_mu != 0
        
      }  // (i!=omit1) &&

    }  // for i

    if (mini!=0)
    {   // new dividing line, going through basei and mini
      omit1 = mini;   // for next iteration
      omit2 = basei;  // for next iteration

      if (totheright)
        // pie at position mini is to the right of line;
        // base is always to the left of line;
        // we have a new division
        // basei and mini are exchanged
      { if (firsttype[basei])
          firstpiecounter --;
        if (firsttype[mini])
          firstpiecounter ++;

        if (origleft[basei])  // it moves to the right now
          nrotherthanorig ++;
        else
          nrotherthanorig --;
        if (origleft[mini])  // it moves to the left now
          nrotherthanorig --;
        else
          nrotherthanorig ++;

          // specifify new dividing line
        dx = x[mini] - basex;
        dy = y[mini] - basey;
        basei = mini;
        basex = x[mini];
        basey = y[mini];

//        cout << "New division determined by following line\n";
//        PrintLine (basex, basey, dx, dy);

        if (firstpiecounter==(N/2))
        { gooddivisionscounter ++;
//          cout << "Good division found by following line\n";
//          PrintLine (basex, basey, dx, dy);
        }

        if (nrotherthanorig==2*N)  // all pieces of pie have moved
                                   // to other side of dividing line
          backtoorigdivision = true;

        if (stepsback > maxstepsback)
          maxstepsback = stepsback;
        stepsback = 0;

      }  // to the right
      else // pie at position mini is to the left
        // because base is also on the left, we do not have a new division,
        // just a new dividing line for the same division
      {   // specify new dividing line
        dx = basex - x[mini];
        dy = basey - y[mini];
        basei = mini;
        basex = x[mini];
        basey = y[mini];
        stepsback ++;
      }  // to the left

    }  // mini!=0
    else  // mini==0; this is not supposed to occur
    {  cout << "No minimum angle computed for following line\n";
       PrintLine (basex, basey, dx, dy);
    }

  }  // while !backtoorigdivision

//  cout << "MaxStepsBack = " << maxstepsback << EOL;

  cout << gooddivisionscounter << EOL;
  
}  // CheckDivisions

//****************************************************************************

int main ()
{ int NInst, Inst;
  int N, i;

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { cin >> N;

    if ((N<2) || (N>MaxN) || (N%2!=0))
      cout << "incorrect value for N at instance " << Inst << ": "
            << N << EOL;
    else  // correct value for N
    { for (i=1;i<=N;i++)
      { cin >> x[i] >> y[i];
        firsttype[i] = true;
      }
      for (i=N+1;i<=2*N;i++)
      { cin >> x[i] >> y[i];
        firsttype[i] = false;
      }

      SortOnX (N);
//      PrintPieces (N);
      CheckDivisions (N);
    }  // correct value for N

  }  // for Inst
  
  return 0;

}
