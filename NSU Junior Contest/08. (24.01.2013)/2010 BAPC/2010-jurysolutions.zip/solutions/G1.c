/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>

#define MAXN 1000
#define ABS(a) ((a) < 0 ? -(a) : (a))

int v[MAXN];

void testcase() {
	int i, N, player;
	int score[2], scoreLeft[2];
	scanf("%d\n", &N);
	for(i = 0; i < N; i++)
		scanf("%d", &v[i]);
	player = 0;
	score[0] = score[1] = 0;
	scoreLeft[0] = scoreLeft[1] = 15 + 15*7 + 2 + 3 + 4 + 5 + 6 + 7;
	i = 0;
	while(scoreLeft[1] >= score[0] - score[1] && scoreLeft[0] >= score[1] - score[0]) {
		if(v[i] == 0) {
			if(i > 0 && v[i-1] == 1)
				scoreLeft[player] -= 7;
			player ^= 1;
		} else if(v[i] == 1) {
			scoreLeft[player^1] -= 8;
			scoreLeft[player]--;
			score[player]++;
		} else {
			score[player] += v[i];
			if(v[i-1] != 1) {
				scoreLeft[0] -= v[i];
				scoreLeft[1] -= v[i];
			} else {
				scoreLeft[player] -= 7;
			}
		}
		i++;
	}
	printf("%d\n", i);
}


int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
