/*
 * BAPC 2010
 * Jeroen Bransen
 */

import java.util.*;
public class geneshuffle_jb {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      int tests = sc.nextInt();
      while(tests-- > 0) {
         int N = sc.nextInt();
         int[] num = new int[N];
         int[] pos = new int[N+1];
         for(int i = 0; i < N; i++)
            num[i] = sc.nextInt();
         for(int i = 0; i < N; i++)
            pos[sc.nextInt()] = i;
         int start = 0;
         int max = 0;
         for(int i = 0; i < N; i++) {
            max = Math.max(max, pos[num[i]]);
            if(max == i) {
               if(start > 0) 
                  System.out.print(' ');
               System.out.print((start+1)+"-"+(i+1));
               start = i+1;
            }
         }
         System.out.println();
      }
   }
}
