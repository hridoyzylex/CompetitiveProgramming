/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MOD 10007
#define MAXN 5000
#define MAXMASK (1<<9)

int dp[MAXN+1][MAXMASK];
bool done[MAXMASK];
int mem[MAXMASK];

int dx[4] = {0, -1, 0, 1};
int dy[4] = {1, 0, -1, 0};

int singlefloor(int mask) {
	int i, j, k;
	if(mask == MAXMASK-1) return 1;
	if(done[mask]) return mem[mask];
	done[mask] = true;
	mem[mask] = 0;
	i = 0;
	while(mask & (1 << i)) i++;
	for(j = 0; j < 4; j++) {
		if((i / 3) + dx[j] >= 0 && (i / 3) + dx[j] < 3 && (i % 3) + dy[j] >= 0 && (i % 3) + dy[j] < 3) {
			k = ((i / 3) + dx[j]) * 3 + (i % 3) + dy[j];
			if(!(mask & (1 << k))) {
				mem[mask] = (mem[mask] + singlefloor(mask | (1<<i) | (1<<k))) % MOD;
			}
		}
	}
	return mem[mask];
}


void preprocess() {
	int i, j, k;
	memset(dp, 0, sizeof(dp));
	memset(done, false, sizeof(done));
	dp[0][0] = 1;
	for(i = 1; i <= MAXN; i++) {
		for(j = 0; j < MAXMASK; j++) {
			for(k = 0; k < MAXMASK; k++) {
				if(k & j) continue;
				dp[i][k] = (dp[i][k] + dp[i-1][j] * singlefloor(k | j)) % MOD;
			}
		}
	}
}

int main() {
	int i, t, N, ret;
	preprocess();
	scanf("%d\n", &t);
	for(i = 1; i <= t; i++) {
		scanf("%d\n", &N);
		if(N <= MAXN) {
			ret = dp[N][0];
		} else {
			ret = -1;
		}
		printf("%d\n", ret);
	}
	return 0;
}
