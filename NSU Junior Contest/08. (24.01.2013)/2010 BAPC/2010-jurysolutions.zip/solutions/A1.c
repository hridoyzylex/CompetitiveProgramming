/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAXN 100000

#define MAX(a, b) ((a) > (b) ? (a) : (b));

int x[MAXN];
int y[MAXN];
int pos[MAXN+1];

void testcase() {
	int i, maxi, j, k, N;
	scanf("%d\n", &N);
	for(i = 0; i < N; i++)
		scanf("%d", &x[i]);
	for(i = 0; i < N; i++) {
		scanf("%d", &y[i]);
		pos[y[i]] = i;
	}
	maxi = 0;
	for(i = 0; i < N; i = maxi + 1) {
		maxi = pos[x[i]];
		for(j = i+1; maxi != j-1; j++)
			maxi = MAX(maxi, pos[x[j]]);
		if(i) printf(" ");
		printf("%d-%d",i+1,maxi+1);
	}
	printf("\n");
}

int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
