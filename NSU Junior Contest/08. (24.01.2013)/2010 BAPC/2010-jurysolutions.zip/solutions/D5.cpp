//First draft of solution for: Collatz
//by Johan de Ruiter

#include <iostream>  
#include <sstream>  
#include <string>  
#include <vector>  
#include <queue>  
#include <set>  
#include <map>  
#include <cstdio>  
#include <cstdlib>  
#include <cctype>  
#include <cmath>  
#include <list>  
#include <numeric> 
#include <ctime>
#include <algorithm>
using namespace std;  
  
typedef vector<int> vi;  
typedef vector<vi> vvi;  
typedef vector<string> vs;  
typedef vector<vs> vvs; 
#define pb push_back  
#define sz(v) ((int)(v).size()) 



int main()
{
  int i,j;
  long long k;

  int run,runs;
  scanf("%d",&runs);
  for(run=0;run<runs;run++)
  {
    scanf("%lld",&k); 
    printf("%lld\n",k-(k/2)+((k+1)/2)-(((k-1)/3)+1)/2);
  }

  return 0;
}

