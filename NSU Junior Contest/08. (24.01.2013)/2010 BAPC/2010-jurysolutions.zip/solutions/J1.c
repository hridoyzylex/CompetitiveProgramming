/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAXH 500
#define MAXV 500
#define MAXL 1000

int hx[MAXH], hy[MAXH], vx[MAXV], vy[MAXV], hlen[MAXH], vlen[MAXV];
char hword[MAXH][MAXL+10], vword[MAXV][MAXL+10];

int cap[MAXH+MAXV+2][MAXH+MAXV+2], flow[MAXH+MAXV+2][MAXH+MAXV+2], done[MAXH+MAXV+2];
int source, sink, nodes, iter;

bool dfs(int i) {
	int j;
	if(i == sink) return true;
	if(done[i] == iter) return false;
	done[i] = iter;
	for(j=0;j<nodes;j++) {
		if(cap[i][j]>flow[i][j]) {
			if(dfs(j)) {
				flow[i][j]++;
				flow[j][i]--;
				return true;
			}
		}
	}
	return false;
}

int match() {
	memset(flow, 0, sizeof(flow));
	memset(done, -1, sizeof(done));
	iter = 0;
	while(dfs(source))
		iter++;
	return iter;
}

bool exclude(int h, int v) {
	if(vx[v] < hx[h] || vx[v] >= hx[h] + hlen[h] || hy[h] < vy[v] || hy[h] >= vy[v] + vlen[v])
		return false;
	return hword[h][vx[v] - hx[h]] != vword[v][hy[h] - vy[v]];
}

void testcase() {
	int H, V, i, j;
	scanf("%d %d\n", &H, &V);
	for(i=0;i<H;i++) {
		scanf("%d %d %s\n",&hx[i],&hy[i],hword[i]);
		hlen[i] = strlen(hword[i]);
	}
	for(i=0;i<V;i++) {
		scanf("%d %d %s\n",&vx[i],&vy[i],vword[i]);
		vlen[i] = strlen(vword[i]);
	}
	source = H+V;
	sink = source+1;
	nodes = sink+1;
	memset(cap, 0, sizeof(cap));
	for(i=0;i<H;i++)
		cap[source][i] = 1;
	for(i=0;i<V;i++)
		cap[H+i][sink] = 1;
	for(i=0;i<H;i++)
		for(j=0;j<V;j++)
			if(exclude(i, j))
				cap[i][H+j] = 1;
	printf("%d\n", H+V-match());
}

int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
