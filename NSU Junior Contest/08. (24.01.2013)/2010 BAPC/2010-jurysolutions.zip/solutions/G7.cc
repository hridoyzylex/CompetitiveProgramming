#include<iostream>
#include<algorithm>
#include<fstream>
using namespace std;

int main() {
    const int startingreds = 15;
    const int maxscore = startingreds*1+startingreds*7+2+3+4+5+6+7; // 147
    int m, n, i, points, previous, decided, turn, remaining[2], score[2]; //, reds;

    cin >> m;

    while(m--) {
        remaining[0] = remaining[1] = maxscore;
        //reds = startingreds;
        decided = turn = previous = score[0] = score[1] = 0;
        cin >> n;

        for(i=1; i<=n; i++) {
            previous = points;
            cin >> points;
            if(points == 0) {
                if(previous == 1)
                    remaining[turn] -= 7;
                turn = (turn + 1) % 2;
            } // if
            else {
                score[turn] += points;
                if(points == 1) {
                    remaining[turn]--;
                    remaining[(turn+1)%2] -= 8;
                    //reds--;
                } // if
                else {
                    if(previous == 1) // reds is helemaal niet nodig :-)
                        remaining[turn] -= 7;
                    else {
                        remaining[turn] -= points;
                        remaining[(turn+1)%2] -= points;
                    }
                } // else
            } // else
            if((score[0] - score[1] > remaining[1] || score[1] - score[0] > remaining[0]) && decided == 0) { 
                decided = i;
            }   
        } // for
        if(decided == 0)
            decided = n;
        cout << decided << endl;
    } // while

    return 0;
} // main

