#include<iostream>
#include<list>
#include<string.h>
#include<limits.h>
#include<algorithm>
using namespace std;

int main() {
    int i, t;
    list<char> L;
    char c[1000010];
    list<char>::iterator it, ait;
    cin >> t;
    cin.getline(c, 1000010);
    int a = 0;
    while(t--) {  a++;
        L.clear();
        //memset(c, 0, sizeof(c));
        cin.getline(c, 1000010);
        i = 0;
        it = L.begin();

        while(c[i]) {
            if(c[i] == '-') {
                if(it != L.begin()) {
                    it--;
                    it = L.erase(it);
                }
            }
            else if(c[i] == '<') {
                if(it != L.begin())
                    it--;
            }
            else if(c[i] == '>') { 
                if(it != L.end())
                    it++;
            }
            else {
                it = L.insert(it, c[i]);
				it++;
            }
            i++;
        }
        for(ait = L.begin(); ait != L.end(); ait++)
            cout << *ait;
        cout << endl;
    } // while
    return 0;
} // main
