//Very fast solution for The Twin Tower that works for N<=10^18
//by Johan de Ruiter

#include <iostream>  
#include <sstream>  
#include <string>  
#include <vector>  
#include <queue>  
#include <set>  
#include <map>  
#include <cstdio>  
#include <cstdlib>  
#include <cctype>  
#include <cmath>  
#include <list>  
#include <numeric> 
#include <ctime>
#include <algorithm>
#include <cstring>
using namespace std;  
  
typedef vector<int> vi;  
typedef vector<vi> vvi;  
typedef vector<string> vs;  
typedef vector<vs> vvs; 
#define pb push_back  
#define sz(v) ((int)(v).size()) 

const int mod=10007;
int M[62][512][512]; //60 and 61 act as registers
int relevant[512],representCount[512],repr[512],Nrelevant=0,ind[512];

int reflect(int in)
{ return ((in&7)<<6)|(in&(7<<3))|(in>>6); }

int rotate(int in)
{
  int i,j,out=0; 
  for(j=0;j<3;j++)
    for(i=0;i<3;i++)
      out|=((in>>(j*3+i))&1)<<(i*3+2-j);
  return out;
}

int minimumOrientation(int in)
{
  int a,b,out=in;
  for(a=0;a<2;a++)
  {
    in=reflect(in);
    for(b=0;b<4;b++)
      out=min(out,in=rotate(in));
  }
  return out;
}

int tilings2D(int in)
{
  if(in==511) return 1;
  
  int k,out=0;
  for(k=0;k<9;k++) if(!(in&(1<<k)))
  {
    if(k<6)
      if(!(in&(9<<k)))
        out+=tilings2D(in|(9<<k));
    if(k%3!=2)
      if(!(in&(3<<k)))
        out+=tilings2D(in|(3<<k));
    break;
  }  
  return out;
}

void matrixMultiplication(int L, int R, int goal)
{
  int i,j,k;
  for(j=0;j<Nrelevant;j++)
    for(i=0;i<Nrelevant;i++)
    {
      long long target=0;
      for(k=0;k<Nrelevant;k++)
        target+=M[L][j][k]*M[R][k][i];
      M[goal][j][i]=target%mod;     
    }
}

void matrixLoad(int loadfrom,int loadto)
{
  int i,j;
  for(j=0;j<Nrelevant;j++) 
    for(i=0;i<Nrelevant;i++)
      M[loadto][j][i]=M[loadfrom][j][i];
}


int main()
{
  memset(M,0,sizeof(M));

  int i,j,k;

  for(j=0;j<512;j++)
  {
    repr[j]=minimumOrientation(j);
    if(representCount[repr[j]]==0)
    {
      ind[j]=Nrelevant;
      relevant[Nrelevant++]=j;
    }
    representCount[repr[j]]++;
  }


  int h0,h1,h2;
  for(h0=0;h0<Nrelevant;h0++) 
  {
    h1=relevant[h0];
    for(h2=0;h2<512;h2++)
    {
      if(h1&h2) continue;

      M[0][h0][ind[repr[h2]]]+=tilings2D(h1|h2);  //sum columns but erase rows
    }
  } 

  for(j=0;j<Nrelevant;j++)
    for(i=0;i<Nrelevant;i++)
      M[0][j][i]%=mod;

  matrixMultiplication(0,0,1);

  vi zag(Nrelevant,0);
  vi Q(1,0); 

  for(int qwijs=0;qwijs<sz(Q);qwijs++)
  {
    if(zag[Q[qwijs]]==0)
    {   
      zag[Q[qwijs]]=1;
      for(i=0;i<Nrelevant;i++)
        if(M[1][Q[qwijs]][i]!=0)
          if(!zag[i])
            Q.pb(i);
    }
  }
  
  int zag2[1000],Nrelevant2=0;
  for(i=0;i<Nrelevant;i++)
    if(zag[i])
      zag2[Nrelevant2++]=i;
      
  for(j=0;j<Nrelevant2;j++) 
    for(i=0;i<Nrelevant2;i++)
      M[0][j][i]=M[1][zag2[j]][zag2[i]];

  Nrelevant=Nrelevant2;
  
  for(k=1;k<60;k++)
  matrixMultiplication(k-1,k-1,k);

  int run,runs;
  scanf("%d",&runs);
  for(run=1;run<=runs;run++)
  {
    long long N;
    scanf("%lld",&N);

//    if(N==0) { printf("1\n",run); continue; }
    if(N==0) { printf("1\n"); continue; }
//    if(N%2) { printf("0\n",run); continue; }
    if(N%2) { printf("0\n"); continue; }
    N/=2;
    
    int bits=0;
    for(i=0;i<60;i++)
      if(N&(1ll<<i))
      {
        if(bits==0)
          matrixLoad(i,60+(bits%2));
        else
          matrixMultiplication(i,60+((bits+1)%2),60+(bits%2));
        
        bits++;
      }
  
    printf("%d\n",M[60+(bits+1)%2][0][0]);
  }

  return 0;
}

