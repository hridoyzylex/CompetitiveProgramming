/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#define MAXN 1000

double min(double a, double b) { return a < b ? a : b; }

int x[MAXN*2], y[MAXN*2], side[MAXN*2];
int count[2][2];

// Which side of the line i-j is p?
int findSide(int i, int j, int p) {
	int dot = (x[j] - x[i]) * (y[p] - y[i]) - (y[j] - y[i]) * (x[p] - x[i]);
	if(dot == 0) {
		fprintf(stderr, "Points are on a line: %d %d %d\n",i,j,p);
		return 0;
	}
	return dot < 0 ? 0 : 1;
}

double angleBounds(double alpha) {
	while(alpha < 0)
		alpha += M_PI * 2;
	while(alpha >= M_PI * 2)
		alpha -= M_PI * 2;
	return alpha;
}

int angleOrder[MAXN*2];
int p1, p2;
int compareAngle(const void *a, const void *b) {
	if(*(int*)a == p1) return -1;
	if(*(int*)b == p1) return 1;
	return atan2(y[*(int*)a]-y[p1],x[*(int*)a]-x[p1])<atan2(y[*(int*)b]-y[p1],x[*(int*)b]-x[p1])?-1:1;
}

void testcase() {
	int i, ret, s1, s2, ar, best, N;
	double besta, currenta;
	scanf("%d\n", &N);
	for(i=0;i<N*2;i++)
		scanf("%d %d\n", &x[i], &y[i]);
	p1 = p2 = 0;
	for(i=0;i<N*2;i++) {
		angleOrder[i] = i;
		if(y[i] > y[p1] || (y[i] == y[p1] && x[i] < x[p1]))
			p1 = i;
	}
	qsort(angleOrder, N*2, sizeof(int), compareAngle);
	p2 = angleOrder[N];
	memset(count, 0, sizeof(count));
	for(i=0;i<N*2;i++) {
		if(i == p1 || i == p2) continue;
		side[i] = findSide(p1, p2, i);
		count[i<N?0:1][side[i]]++;
	}
	s1 = p1; s2 = p2;
	ret = 0;
	do {
		if((p1<N)==(p2<N)) {
			if(count[p1<N?0:1][0]==count[p1<N?0:1][1] && count[p1<N?1:0][0]==count[p1<N?1:0][1])
				ret += 2;
		} else {
			if(count[p1<N?0:1][0]-count[p1<N?0:1][1] == 1 && count[p1<N?1:0][0]-count[p1<N?1:0][1] == -1)
				ret++;
			else if(count[p1<N?0:1][0]-count[p1<N?0:1][1] == -1 && count[p1<N?1:0][0]-count[p1<N?1:0][1] == 1)
				ret++;
		}

		if(count[0][0]+count[1][0]<=count[0][1]+count[1][1])
			ar = p1;
		else
			ar = p2;
		best = -1;
		for(i = 0; i < N*2; i++) {
			if(i == p1 || i == p2) continue;
			currenta = atan2(y[i]-y[ar],x[i]-x[ar])-atan2(y[ar==p1?p2:p1]-y[ar],x[ar==p1?p2:p1]-x[ar]);
			currenta = min(angleBounds(currenta),angleBounds(currenta+M_PI));
			if(best == -1 || (currenta < besta)) {
				best = i;
				besta = currenta;
			}
		}
		if(ar == p1) {
			if(side[best]==0) {
				side[p2] = findSide(best, p1, p2);
				count[p2<N?0:1][side[p2]]++;
				count[best<N?0:1][side[best]]--;
				p2 = p1;
				p1 = best;
			} else {
				side[p2] = findSide(p1, best, p2);
				count[p2<N?0:1][side[p2]]++;
				count[best<N?0:1][side[best]]--;
				p2 = best;
			}
		} else {
			if(side[best]==1) {
				side[p1] = findSide(p2, best, p1);
				count[p1<N?0:1][side[p1]]++;
				count[best<N?0:1][side[best]]--;
				p1 = p2;
				p2 = best;
			} else {
				side[p1] = findSide(best, p2, p1);
				count[p1<N?0:1][side[p1]]++;
				count[best<N?0:1][side[best]]--;
				p1 = best;
			}
		}
	} while(s1 != p2 || s2 != p1);
	printf("%d\n", ret/2);
}

int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
