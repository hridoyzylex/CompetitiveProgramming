// Problem: Pie division
// Author: Rudy van Vliet
// Date: 15 June 2010

// Slow version, where we just check all possible dividing line
// 1) if they divide the pies in two groups of N
// 2) and if the pies of each type are equally divided over both groups.
// Complexity: O(N^3).
// Program seems to work well.

#include <iostream>
using namespace std;

const int MaxN = 1000;
const char EOL = '\n';
int x[2*MaxN+1],
    y[2*MaxN+1];
bool firsttype[2*MaxN+1];
int tmpx[2*MaxN+1],
    tmpy[2*MaxN+1];
bool tmpfirsttype[2*MaxN+1];

//****************************************************************************

void PrintPieces (int N)
{ int i;

  for (i=1;i<=2*N;i++)
    cout << x[i] << ' ' << y[i] << ' ' << firsttype[i] << EOL;

}  // PrintPieces

//****************************************************************************

void PrintLine (int basex, int basey, int dx, int dy)
{
  cout << "Line at base (" << basex << "," << basey << ") and with direction ("
       << dx << "," << dy << ")\n";

}  // PrintLine

//****************************************************************************

void CheckDivisions (int N)
{ int gooddivisionscounter,  // counts the good divisions
      i, j, k,
      dx, dy, basex, basey,  // specify dividing line
      totalpiestotheleft,  // total number of pies to the left
                           // of dividing line
      firstpiecounter,  // number of pies of first type to the left
                        // of dividing line
      firstpieextra,
      numer_lambda,  // numerator of lambda
      numer_mu;      // numerator of mu

  gooddivisionscounter = 0;

  for (i=1;i<=2*N-1;i++)
  { basex = x[i];
    basey = y[i];

    for (j=i+1;j<=2*N;j++)  // check the two dividing lines determined
                            // by pies at position i and j:
                            // the one with i left and j right
                            // and the one with i right and j left
    { dx = x[j] - x[i];
      dy = y[j] - y[i];

      totalpiestotheleft = 0;    // counts the total number pies
                            // to the left of dividing line
      firstpiecounter = 0;  // counts the number of pies of first type
                            // to the left of dividing line

      for (k=1;k<=2*N;k++)
      { if ((k!=i) && (k!=j))
        {
           // check if pie at position k is to the left of dividing line
           // first, determine (lambda, mu) such that
           //   (x[k],y[k]) = (basex, basey) + lambda (dx, dy) + mu (dy, -dx)
           //   mu > 0  implies that (x[k],y[k]) is to the right of dividing line
          numer_lambda = dy*(y[k] - basey) + dx*(x[k]-basex);
            // the denominator = (dy*dy + dx*dx)
          numer_mu = - dx*(y[k] - basey) + dy*(x[k]-basex);
            // the denominator = (dy*dy + dx*dx)

//          cout << "i=" << i << " and (lambda,mu) = (" << numer_lambda
//               << "," << numer_mu << ")\n";

          if (numer_mu==0)  // this is not supposed to occur
          { cout << "Pie at position " << k << " is also at following line\n";
            PrintLine (basex, basey, dx, dy);
          }
          else  // numer_mu != 0
          {
            if (numer_mu<0)  // (x[k],y[k]) is to the left of dividing line
            { totalpiestotheleft ++;
              if (firsttype[k])
                firstpiecounter ++;
            }

          }  // numer_mu != 0

        }  // k!=i and k!=j
      }  // for k

      if (totalpiestotheleft==N-1)
      {   // add pie at position i (the base)
          // to group of pies to the left of dividing line
        if (firsttype[i])  // pie of first type
          firstpieextra = 1;
        else
          firstpieextra = 0;

        if (firstpiecounter + firstpieextra == N/2)
        { gooddivisionscounter ++;
//          cout << "Good division found by following line\n";
//          PrintLine (basex, basey, dx, dy);
        }

          // now add pie at position j (instead of the one at position i)
          // to group of pies to the left of dividing line

          // One may think that this second division does not have
          // to be considered here, as it may be found when checking
          // another dividing line. This is not true in general, as we
          // may check that other dividing line in the wrong direction
          // (dx, dy).
          // Indeed, this way, we check every division exactly twice.
        if (firsttype[j])  // pie of first type
          firstpieextra = 1;
        else
          firstpieextra = 0;

        if (firstpiecounter + firstpieextra == N/2)
        { gooddivisionscounter ++;
//          cout << "Good division found by following line\n";
//          PrintLine (x[j], y[j], dx, dy);
        }

      }  // totalpiestotheleft==N-1

    }  // for j
  }  // for i
 
    // each good division is counted double
  if (gooddivisionscounter%2==1)
    cout << "Number of good divisions) is " << gooddivisionscounter << EOL;
  else
    cout << (gooddivisionscounter/2) << EOL;
  
}  // CheckDivisions

//****************************************************************************

int main ()
{ int NInst, Inst;
  int N, i;

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { cin >> N;

    if ((N<2) || (N>MaxN) || (N%2!=0))
      cout << "incorrect value for N at instance " << Inst << ": "
            << N << EOL;
    else  // correct value for N
    { for (i=1;i<=N;i++)
      { cin >> x[i] >> y[i];
        firsttype[i] = true;
      }
      for (i=N+1;i<=2*N;i++)
      { cin >> x[i] >> y[i];
        firsttype[i] = false;
      }

//      PrintPieces (N);
      CheckDivisions (N);
    }  // correct value for N

  }  // for Inst
  
  return 0;

}
