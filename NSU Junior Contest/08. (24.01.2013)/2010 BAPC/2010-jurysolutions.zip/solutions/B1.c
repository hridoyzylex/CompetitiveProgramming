/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>

#define MAXN 50000
#define MIN(a, b) ((a) < (b) ? (a) : (b))

int x[MAXN+1];
int dp[MAXN+1];
int a, b, M;

int blockpenalty(int len) {
	return len < M ? b * (M - len) : a * (len - M);
}

void testcase() {
	int i, j, N, sum, totalsum;
	scanf("%d %d\n", &N, &M);
	scanf("%d %d\n", &a, &b);
	for(i = 0; i < N; i++)
		scanf("%d", &x[i]);
	dp[0] = 0;
	totalsum = 0;
	for(i = 0; i < N; i++) {
		totalsum += x[i];
		dp[i+1] = MIN(blockpenalty(totalsum), blockpenalty(x[i]) + dp[i]);
		sum = x[i];
		for(j = i - 1; j >= 0; j--) {
			sum += x[j];
			dp[i+1] = MIN(dp[i+1], blockpenalty(sum) + dp[j]);
			if(sum > M) break;
		}
	}
	printf("%d\n", dp[N]);
}


int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
