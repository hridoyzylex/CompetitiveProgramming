/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MOD 10007

#define MAXN 1<<8
#define MAXM MAXN

struct matrix {
    int n, m;
    int data[MAXN][MAXM];
};

struct matrix *multiply(const struct matrix *a, const struct matrix *b)
{
	int i, j, k;
	struct matrix *rv = malloc(sizeof(struct matrix));
	rv->n = a->n;
	rv->m = b->m;

	for (i = 0; i < rv->n; i++) {
		for (j = 0; j < rv->m; j++) {
			rv->data[i][j] = 0;
			for (k = 0; k < a->m; k++) {
				rv->data[i][j] += a->data[i][k] * b->data[k][j];
				rv->data[i][j] %= MOD;
			}
		}
	}
	return rv;
}

struct matrix *power(const struct matrix *a, int n)
{
	struct matrix *rv, *rv2;
	int i;
	if (n == 0) {
		rv = malloc(sizeof(struct matrix));
		rv->n = a->n;
		rv->m = a->m;
		memset(rv->data, 0, sizeof(rv->data));
		for (i = 0; i < rv->n; i++)
			rv->data[i][i] = 1;
		return rv;
	}

	if (n == 1) {
		rv = malloc(sizeof(struct matrix));
		memcpy(rv, a, sizeof(*a));
		return rv;
	}

	rv = power(a, n / 2);
	rv2 = multiply(rv, rv);
	free(rv);
	if (n & 1) {
		rv = multiply(rv2, a);
		free(rv2);
		return rv;
	} else {
		return rv2;
	}
}

struct matrix *inp;
bool done[1<<9];
int mem[1<<9];

int dx[4] = {0, -1, 0, 1};
int dy[4] = {1, 0, -1, 0};

int rec(int mask) {
	int i, j, k;
	if(mask == (1<<9)-1) return 1;
	if(done[mask]) return mem[mask];
	done[mask] = true;
	mem[mask] = 0;
	i = 0;
	while(mask & (1 << i)) i++;
	for(j = 0; j < 4; j++) {
		if((i / 3) + dx[j] >= 0 && (i / 3) + dx[j] < 3 && (i % 3) + dy[j] >= 0 && (i % 3) + dy[j] < 3) {
			k = ((i / 3) + dx[j]) * 3 + (i % 3) + dy[j];
			if(!(mask & (1 << k))) {
				mem[mask] = (mem[mask] + rec(mask | (1<<i) | (1<<k))) % MOD;
			}
		}
	}
	return mem[mask];
}

int bitcount(int i) {
	int ret = 0;
	while(i) {
		ret += (i & 1);
		i >>= 1;
	}
	return ret;
}

void preprocess() {
	int i, j, k, ind1, ind2;
	memset(done, false, sizeof(done)); 
	inp = malloc(sizeof(struct matrix));
	inp->n = 1<<8;
	inp->m = 1<<8;
	ind1 = 0;
	for(i = 0; i < (1<<9); i++) {
		if((bitcount(i) & 1) == 0) {
			ind2 = 0;
			for(j = 0; j < (1<<9); j++) {
				if((bitcount(j) & 1) == 0) {
					inp->data[ind1][ind2] = 0;
					for(k = 0; k < (1<<9); k++) {
						if((bitcount(k) & 1) == 1 && (i & k) == 0 && (k & j) == 0) {
							inp->data[ind1][ind2] += (rec(i | k) * rec(k | j)) % MOD;
						}
					}
					ind2++;
				}
			}
			ind1++;
		}
	}
}

int testcase(int N) {
	int v;
	struct matrix *ret;
	ret = power(inp, N);
	v = ret->data[0][0];
	free(ret);
	return v;
}

int main() {
	int i, t, N, ret;
	preprocess();
	scanf("%d\n", &t);
	for(i = 1; i <= t; i++) {
		scanf("%d\n", &N);
		if(N & 1) {
			ret = 0;
		} else {
			ret = testcase(N / 2);
		}
		printf("%d\n", ret);
	}
	return 0;
}
