/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
	int t, n;
	for(scanf("%d\n", &t); t--; printf("%d\n",(n+1)/2+(n+1)/2-((n-1)/3+1)/2))
		scanf("%d\n", &n);
	return 0;
}
