// Problem: The Twin Tower
// Author: Rudy van Vliet
// Date: 21 October 2010

// Uses dynamic programming to count the number of possibilities
// up to one floor from the number of possibilities up to the previous
// floor.
//   Rooms on a certain floor are numbered as follows:
//        1 | 2 | 3
//        _ _ _ _ _
//
//        4 | 5 | 6
//        _ _ _ _ _
//
//        7 | 8 | 9
// Room 1 corresponds to the least significant bit of an integer 0..511
// Room 2 corresponds to the least-but-one significant bit of an integer 0..511
//   ...
// Room 9 corresponds to the most significant bit of an integer 0..511
//
// Time complexity: at most O(N * 512 * 512)
// Program seems to work well

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const int MinN = 0;
const int MaxN = 5000;      // maximum number of floors
const int prime = 10007;
const char EOL = '\n';

int Powers[10],        // Powers of 2. On positions 1..9, we store  2^{0}..2^{8}
    NrBits[512],       // NrBits[k] contains number of bits (that are 1) in k
    Subsets[512][10],  // Subsets[k] contains bits in k (from {1,...,9})
                       // in increasing order (so they do not have
                       // to be recomputed over and over again).
                       // Bits are stored in Subsets[k][1..9], so we do
                       // not use Subsets[k][0].
    NrUsefulSubsets[512],  // Number of useful subsets of k:
                           // Given the bits in k, how many subsets of these
                           // bits are there, such that the remaining bits
                           // (or rooms) can be paired `flat'.
    UsefulSubsets[512][512], // Useful subsets of k:
                           // Given the bits in k, for which subsets
                           // of these bits can the remaining bits (or rooms)
                           // be paired `flat' (we do not store the subsets
                           // itself, but the corresponding value
    FP[512],      // number of Flat Pairings of subset of rooms 1..9
                  // i.e., no room is paired to a room at another floor
    A1[512],      // A1[k]/A2[k] for floor f: number of pairings of rooms
                  // (modulo prime),
    A2[512],      //   where rooms corresponding to bits in k are paired
                  //   up to floor f,
                  // and rooms corresponding to bits not in k are paired
                  //   up to floor f-1.
    NrP[MaxN+1];  // number of pairings of all rooms on floors 1..N
                  // (modulo prime)
    
//****************************************************************************

void IntSwap (int &x, int &y)
 // swap x and y
{ int tmp;

  tmp = x;
  x = y;
  y = tmp;

}  // IntSwap

//****************************************************************************
    
void DeterminePowersSubsets ()
 // Fill the arrays Powers, NrBits and Subsets
{ int pow,
      b,
      k,
      tmp;

  pow = 1;
  for (b=1;b<=9;b++) 
  { Powers[b] = pow;
    pow *= 2;
  }  // for b

  for (k=0;k<=511;k++)
  { NrBits[k] = 0;
    tmp = k;
    for (b=1;b<=9;b++)
    { if (tmp%2==1)
      { NrBits[k] ++;
        Subsets[k][NrBits[k]] = b;
      }
      tmp = tmp/2;
    }  // for b
  }  // for k

}  // DeterminePowersSubsets

//****************************************************************************

bool FirstSubset (int *Subset, int maxelt, int setsize)
 // Construct the first subset in a series of subsets of {1,..,maxelt}
 // of size setsize: {1,...,setsize}. These elements will be put on positions
 // 1,...,setsize of array Subset
 // Return  true:   if this is possible
 //         false:  if this is not possible (i.e., setsize > maxelt)
 // Pre: size of array Subset is at least setsize+1 (since we do not use
 //        position 0
{ int i;

  if (setsize<=maxelt)
  { for (i=1;i<=setsize;i++)
      Subset[i] = i;
    return true;
  }
  else
  { cout << "Unable to construct a subset of a set larger than the set itself.\n";
    return false;
  }

}  // FirstSubset
    
//****************************************************************************

bool NextSubset (int *Subset, int maxelt, int setsize)
 // Construct the next subset in a series of subsets of {1,..,maxelt}
 // of size setsize, after the current subset: this next subset is formed
 // by increasing the largest element of the subset than can be increased.
 // In principle, this is Subset[setsize], but if this element equals maxelt,
 // we have to increase an earlier element.
 // Elements in Subset are stored at positions 1,...,setsize.
 // Return  true:   if this is possible
 //         false:  if this is not possible (i.e., setsize > maxelt,
 //                   or we already have the last subset)
 // Pre: size of array Subset is at least setsize+1 (since we do not use
 //        position 0
{ int i;

  if (setsize <= maxelt)
  { i = setsize;
    while ((i>0) && (Subset[i] + setsize - i == maxelt))
      i--;

    if (i>=1)
    { Subset[i] ++;
      while (i<setsize)
      { i++;
        Subset[i] = Subset[i-1] + 1;
      }

      return true;
    }
    else  // i=0 -> we already have the last subset
      return false;
    
  }
  else
  { cout << "Unable to construct (next) subset of a set larger than the set itself.\n";
    return false;
  }

}  // NextSubset

//****************************************************************************

bool Adjacent (int r1, int r2)
 // Check if rooms r1 and r2 (on the same floor) are adjacent
 // Pre: 1 <= r1, r2 <= 9
{
  if (r1>r2)
    IntSwap (r1, r2);

  if (r2==r1+3)
    return true;
  else
    if ((r2==r1+1) && ( (r1-1)/3 == (r2-1)/3) )
      return true;
    else
      return false;

}  // Adjacent

//****************************************************************************

void FillFP ()
 // Fill array FP
{ int k, kremainder,
      nr,
      Subset[10],  // subset of 1,...9, on positions 1,..,nr
      i;
  bool Continue;

  // start with (only) subset of size 0
  FP[0] = 1;  // one (trivial) pairing of 0 rooms

  for (k=1;k<=511;k++)  // initialize the rest
    FP[k] = 0;

  for (nr=2;nr<=8;nr+=2)
  {
    FirstSubset (Subset, 9, nr);

    do
    {
      k = 0;
      for (i=1;i<=nr;i++)
        k += Powers[Subset[i]];

        // in a pairing of all rooms in the Subset,
        // Subset[1] (the first room) must be paired to some room Subset[i]
      for (i=2;i<=nr;i++)
        if (Adjacent (Subset[1], Subset[i]) )
        { kremainder = k - Powers[Subset[1]] - Powers[Subset[i]];
          FP[k] += FP[kremainder];
        }

      FP[k] = FP[k] % prime;  // for consistency, although not necessary

      Continue = NextSubset (Subset, 9, nr);

    }  while (Continue);

  }  // for nr

//  for (k=0;k<=511;k++)
//    cout << FP[k] << EOL;

}  // FillFP

//****************************************************************************

void FillUsefulSubsets ()
 // Fill array UsefulSubsets
{ int k,
      startnr, nr,
      value,
      kremainder,
      i,
      Subset[10];
  bool Continue;
  int  MaxNrUsefulSubsets;

  MaxNrUsefulSubsets = 0;

  for (k=0;k<=511;k++)
  {
    NrUsefulSubsets[k] = 0;

      // in order for a subset of the bits in k to be useful, the number
      // of remaining bits must be even
    if (NrBits[k]%2==0)
      startnr = 0;
    else
      startnr = 1;

    for (nr=startnr;nr<=NrBits[k];nr+=2)
    {
      FirstSubset (Subset, NrBits[k], nr);

      do
      {
        value = 0;
        for (i=1;i<=nr;i++)
          value += Powers[ Subsets[k] [Subset[i]] ];
            // the power corresponding to the Subset[i]'th bit of k

        kremainder = k - value;
        if (FP[kremainder] > 0)  // value denotes a useful subset of k
        { NrUsefulSubsets[k] ++;
          UsefulSubsets[k] [ NrUsefulSubsets[k] ] = value;
        }

        Continue = NextSubset (Subset, NrBits[k], nr);
      } while (Continue);

    }  // for nr

    if (NrUsefulSubsets[k] > MaxNrUsefulSubsets)
      MaxNrUsefulSubsets = NrUsefulSubsets[k];

  }  // for k

//  cout << "MaxNrUsefulSubsets = " << MaxNrUsefulSubsets << EOL;

}  // FillUsefulSubsets

//****************************************************************************

void ComputeFloor (int *A, int *B, int f)
 // Compute the contents of array A (either A1 or A2) from the contents
 // of array B (the other array).
 // A is the array for floor f, and B is the array for floor f-1.
 // If f is even, then A=A2 and B=A1.
 // If f is odd, then A=A1 and B=A2.
{ int parity,
      k,
      i,
      value;

  if (f%2==0)   // for an even floor, the number of rooms paired must be odd
    parity = 1; // (hence, the number of remaining rooms is even)
  else
    parity = 0; // for an odd floor, the number of rooms paired must be even

  for (k=0;k<=511;k++)
  { if (NrBits[k]%2==parity)
    {
      A[k] = 0;  // initialization

      // An even number of the rooms must be paired with a room
      // at the same floor. The other rooms must be paired with a room
      // at the floor below.
      // The useful subsets (of these other rooms) of k are stored
      // in UsefulSubsets.

      for (i=1;i<=NrUsefulSubsets[k];i++)
      {
        value = UsefulSubsets[k][i];
          // The remaining rooms on this floor (k-value) must be paired `flat'
          // On the floor below we also lose the rooms corresponding to value.
        A[k] += FP[k-value]*B[511-value];
      }  // for i

      A[k] = A[k] % prime;

    }  // k has the right parity for floor f
    else  // k has the wrong parity for floor f
      A[k] = 0;

  }  // for k

  NrP[f] = A[511];

}  // ComputeFloor

//****************************************************************************

void FillNrP (int ThisMaxN)
 // Fill positions 0..ThisMaxN of array NrP.
 // We fill at least positions 0..1 (even if ThisMaxN==0).
{ int k,
      f;

  NrP[0] = 1;
  for (k=0;k<=511;k++)  // first floor can only be filled with flat parings
    A1[k] = FP[k];
  NrP[1] = A1[511];     // which is 0

  for (f=2;f<=ThisMaxN;f++)
  {
    if (f%2==0)  // f is even
      ComputeFloor (A2, A1, f);
    else  // f is odd
      ComputeFloor (A1, A2, f);

  }  // for f

}  // FillNrP

//****************************************************************************

int main ()
{ int NInst, Inst;
  int N;  // the number of floors

  DeterminePowersSubsets ();
  FillFP ();
  FillUsefulSubsets ();
  FillNrP (MaxN);

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { cin >> N;

    if ((N>=MinN) && (N<=MaxN))
      cout << NrP[N] << EOL;
    else
      cout << "Number of floors is out of bounds.\n";

  }  // for Inst
  
  return 0;

}
