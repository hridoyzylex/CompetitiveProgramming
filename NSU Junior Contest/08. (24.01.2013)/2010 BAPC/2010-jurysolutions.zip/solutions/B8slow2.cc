// Problem: Top 2000
// Author: Rudy van Vliet
// Date: 19 August 2010

// Uses recursion.
// Note: we do store the intermediate results, but that is meant only
// to reconstruct the schedule afterwards. We do not use the intermediate
// results in the recursion; we recompute them over and over again.
//
// Very bad time complexity: exponential.
// Program seems to work well.

#include <iostream>
using namespace std;

const int MaxN = 50000;
const int MaxBlocksize = 100;
const int MinBlocksize = 15;
const int MaxPenalty = 1000;
const int MaxLen = 20;
const char EOL = '\n';
int Length[MaxN+1],
    PenWBA[MaxN+1],  // (minimum) Penalty for singles 1...i
                     // With Break After single i
    FirstIInSchedule[MaxN+1],  // stores the schedule:
                     // if there is a break after single i,
                     // then block ending with single i starts with FirstI
    TotalSubsums[MaxN+1];  // sum of lengths of singles 1...i
                     // prefix `Total' indicates that we start with single 1

//****************************************************************************

bool CheckParameters (int N, int Blocksize, int a, int b, int Inst)
 // check values of parameters
{ bool OK;

  OK = true;

  if ((N<1) || (N>MaxN))
  { cout << "incorrect value for N at instance " << Inst << ": "
          << N << EOL;
    OK = false;
  }

  if ((Blocksize<MinBlocksize) || (Blocksize>MaxBlocksize))
  { cout << "incorrect value for Blocksize at instance " << Inst << ": "
          << Blocksize << EOL;
    OK = false;
  }

  if ((a<1) || (a>MaxPenalty))
  { cout << "incorrect value for penalty a at instance " << Inst << ": "
          << a << EOL;
    OK = false;
  }

  if ((b<1) || (b>MaxPenalty))
  { cout << "incorrect value for penalty b at instance " << Inst << ": "
          << b << EOL;
    OK = false;
  }

  return OK;

}  // CheckParameters

//****************************************************************************

int Penalty (int Sum, int Blocksize, int a, int b)
 // compute penalty when singles with total length Sum are scheduled
 // in a block of size Blocksize.
{
  if (Sum > Blocksize)  // singles are too long; we have to cut the difference
    return (a * (Sum - Blocksize));
  else  // singles are too short; remaining time must be filled by DJ
    return (b * (Blocksize - Sum));

}  // Penalty

//****************************************************************************

int ComputeMinPenalty (int n, int Blocksize, int a, int b)
 // compute minimum penalty for schedule of n singles 1...n
 // pre: 0 <= n <= N
{ int SubSum,  // sum of subsequence of lengths from FirstI to i (inclusive)
      SubSum1, SubSum2,
      i,
      i1, i2,
      MinPenalty,  // minimum Penalty for singles 1...n
                   // with break after single n
      Penalty1, Penalty2;

  if (n==0)  // no singles to be played
  { MinPenalty = 0;
    PenWBA[n] = MinPenalty;
  }
  else  // n > 0
  { i = n;
    SubSum = Length[i];

    if (SubSum >= Blocksize)  // no choice, we have to play single n;
      // It does not help to add more singles to this block,
      // unless... (see below)
    { FirstIInSchedule[n] = i;
      MinPenalty = ComputeMinPenalty (i-1, Blocksize, a, b) +
                     Penalty (SubSum, Blocksize, a, b);
      PenWBA[n] = MinPenalty;
    }
    else  // initially, SubSum < Blocksize.
          // add singles, until we exceed Blocksize
    { while ((SubSum < Blocksize) && (i>1))
      { i--;
        SubSum += Length[i];
      }

       // three possibilities:
       // - SubSum < Blocksize: hence, i==1 and all singles fit in one block.
       //   Recursion stops here.
       // - SubSum == Blocksize (and i>=1): hence, singles i...n fit exactly
       //   in one block. No need to try two schedules
       // - SubSum > Blocksize (and i>=1). Choose between schedule with
       //   i...n in a block and schedule with i+1...n in a block
       // In fact, the first two possiblities could as well be combined,
       // but we treat them separately for the sake of clearness.
       //
       // Once SubSum >= Blocksize (the last two possibilities)
       // it does not help to add more singles to this block,
       // unless... (see below)
      if (SubSum < Blocksize)
      { FirstIInSchedule[n] = i;
        MinPenalty = Penalty (SubSum, Blocksize, a, b);
        PenWBA[n] = MinPenalty;
      }
      else  // SubSum >= Blocksize
      { if (SubSum == Blocksize)
        { FirstIInSchedule[n] = i;
          MinPenalty = ComputeMinPenalty (i-1, Blocksize, a, b);
          PenWBA[n] = MinPenalty;
        }
        else  // SubSum > Blocksize
        {   // first schedule: singles i...n in a block
          i1 = i;
          SubSum1 = SubSum;
          Penalty1 = ComputeMinPenalty (i1-1, Blocksize, a, b) +
                         Penalty (SubSum1, Blocksize, a, b);
            // second schedule: singles i+1...n in a block
          i2 = i+1;
          SubSum2 = SubSum - Length[i];
          Penalty2 = ComputeMinPenalty (i2-1, Blocksize, a, b) +
                         Penalty (SubSum2, Blocksize, a, b);

          if (Penalty1 <= Penalty2)  // first schedule is optimal
          { FirstIInSchedule[n] = i1;
            MinPenalty = Penalty1;
            PenWBA[n] = MinPenalty;
          }
          else  // second schedule is optimal
          { FirstIInSchedule[n] = i2;
            MinPenalty = Penalty2;
            PenWBA[n] = MinPenalty;
          }

        }  // else: SubSum > Blocksize
      }  // else: SubSum >= Blocksize

    }  // else: initially SubSum < Blocksize
  }

   // Once Subsum >= Blocksize, we have not added more singles
   // to this block. The reason is that they could as well be added
   // to the previous block
   //
   // Unless... there is no such previous block
   // Therefore, also check a schedule with all singles in one block
  Penalty2 = Penalty (TotalSubsums[n], Blocksize, a, b);
  if (Penalty2 < MinPenalty)
  { FirstIInSchedule[n] = 1;
    MinPenalty = Penalty2;
    PenWBA[n] = MinPenalty;
  }

  return MinPenalty;

}  // ComputeMinPenalty

//****************************************************************************

void PrintSchedule (int i, int &BlockNr)
 // recursively print the schedule for singles 1...i
{
  if (FirstIInSchedule[i]==1)
  { BlockNr = 1;
  }
  else
  { PrintSchedule (FirstIInSchedule[i]-1, BlockNr);
    BlockNr ++;
  }

  cout << "Block " << BlockNr << " : " << FirstIInSchedule[i] << "..." << i
       << "  Penalty " << PenWBA[i] - PenWBA[FirstIInSchedule[i]-1] << EOL; 

}  // PrintSchedule

//****************************************************************************

int main ()
{ int NInst, Inst;
  int N, Blocksize,  // Blocksize is M from problem statement
      a, b;
  bool OK;
  int i, len;
  int MinPenalty;
//  int BlockNr;

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { cin >> N >> Blocksize;
    cin >> a >> b;

    OK = CheckParameters (N, Blocksize, a, b, Inst);

    TotalSubsums[0] = 0;

    for (i=1;i<=N;i++)
    { cin >> len;  // continue reading input, even if some value was not OK
      if ((len<1) || (len>MaxLen))
      { cout << "incorrect value for length of single " << i
             << " at instance " << Inst << ": " << len << EOL;
        OK = false;
      }
      if (OK)
      { Length[i] = len;
        TotalSubsums[i] = TotalSubsums[i-1] + len;
      }
    }

    if (OK)
    {
      MinPenalty = ComputeMinPenalty (N, Blocksize, a, b);
//      PrintSchedule (N, BlockNr);
      cout << MinPenalty << EOL;

    }  // correct input

  }  // for Inst
  
  return 0;

}
