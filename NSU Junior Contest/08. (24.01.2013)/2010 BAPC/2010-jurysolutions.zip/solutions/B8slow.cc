// Problem: Top 2000
// Author: Rudy van Vliet
// Date: 19 August 2010

// Uses dynamic programming.
// Bad time complexity: O (N^2)
// Program seems to work well.

#include <iostream>
using namespace std;

const int MaxN = 50000;
const int MaxBlocksize = 100;
const int MinBlocksize = 15;
const int MaxPenalty = 1000;
const int MaxLen = 20;
const char EOL = '\n';
int Length[MaxN+1],
    PenWBA[MaxN+1],  // (minimum) Penalty for singles 1...i
                     // With Break After single i
    FirstIInSchedule[MaxN+1];  // stores the schedule:
                     // if there is a break after single i,
                     // then block ending with single i starts with FirstI

//****************************************************************************

bool CheckParameters (int N, int Blocksize, int a, int b, int Inst)
 // check values of parameters
{ bool OK;

  OK = true;

  if ((N<1) || (N>MaxN))
  { cout << "incorrect value for N at instance " << Inst << ": "
          << N << EOL;
    OK = false;
  }

  if ((Blocksize<MinBlocksize) || (Blocksize>MaxBlocksize))
  { cout << "incorrect value for Blocksize at instance " << Inst << ": "
          << Blocksize << EOL;
    OK = false;
  }

  if ((a<1) || (a>MaxPenalty))
  { cout << "incorrect value for penalty a at instance " << Inst << ": "
          << a << EOL;
    OK = false;
  }

  if ((b<1) || (b>MaxPenalty))
  { cout << "incorrect value for penalty b at instance " << Inst << ": "
          << b << EOL;
    OK = false;
  }

  return OK;

}  // CheckParameters

//****************************************************************************

int Penalty (int Sum, int Blocksize, int a, int b)
 // compute penalty when singles with total length Sum are scheduled
 // in a block of size Blocksize.
{
  if (Sum > Blocksize)  // singles are too long; we have to cut the difference
    return (a * (Sum - Blocksize));
  else  // singles are too short; remaining time must be filled by DJ
    return (b * (Blocksize - Sum));

}  // Penalty

//****************************************************************************

int ComputeMinPenalty (int N, int Blocksize, int a, int b)
 // compute minimum penalty for complete schedule of N singles
{ int SubSum,  // sum of subsequence of lengths from FirstI to i (inclusive)
      FirstI,  // position of first single in SubSum
      i,
      MinPenalty,  // minimum Penalty (for the moment) for singles 1...i
                   // With Break After single i
      MinFirstI,   // FirstI corresponding with minimum penalty
      NewPenalty;

  PenWBA[0] = 0;
  
  for (i=1;i<=N;i++)
  {  // compute (minimum) Penalty for singles 1...i With Break After single i

     // start with block containing only single i;
     // while there are earlier singles, add them

    SubSum = Length[i];
    FirstI = i;
    MinPenalty = PenWBA[FirstI-1] + Penalty (SubSum, Blocksize, a, b);
    MinFirstI = FirstI;

      // try to find schedule with smaller penalty
    while (FirstI>1)
    {  // add single FirstI-1 to this block
      FirstI --;
      SubSum += Length[FirstI];
      NewPenalty = PenWBA[FirstI-1] + Penalty (SubSum, Blocksize, a, b);
      if (NewPenalty < MinPenalty)
      { MinPenalty = NewPenalty;
        MinFirstI = FirstI;
      }

    }  // while

    PenWBA[i] = MinPenalty;
    FirstIInSchedule[i] = MinFirstI;
    
  }  // for i

  return PenWBA[N];

}  // ComputeMinPenalty

//****************************************************************************

void PrintSchedule (int i, int &BlockNr)
 // recursively print the schedule for singles 1...i
{
  if (FirstIInSchedule[i]==1)
  { BlockNr = 1;
  }
  else
  { PrintSchedule (FirstIInSchedule[i]-1, BlockNr);
    BlockNr ++;
  }

  cout << "Block " << BlockNr << " : " << FirstIInSchedule[i] << "..." << i
       << "  Penalty " << PenWBA[i] - PenWBA[FirstIInSchedule[i]-1] << EOL; 

}  // PrintSchedule

//****************************************************************************

int main ()
{ int NInst, Inst;
  int N, Blocksize,  // Blocksize is M from problem statement
      a, b;
  bool OK;
  int i, len;
  int MinPenalty;
//  int BlockNr;

  cin >> NInst;
  for (Inst=1;Inst<=NInst;Inst++)
  { cin >> N >> Blocksize;
    cin >> a >> b;

    OK = CheckParameters (N, Blocksize, a, b, Inst);

    for (i=1;i<=N;i++)
    { cin >> len;  // continue reading input, even if some value was not OK
      if ((len<1) || (len>MaxLen))
      { cout << "incorrect value for length of single " << i
             << " at instance " << Inst << ": " << len << EOL;
        OK = false;
      }
      if (OK)
        Length[i] = len;
    }

    if (OK)
    {
      MinPenalty = ComputeMinPenalty (N, Blocksize, a, b);
//      PrintSchedule (N, BlockNr);
      cout << MinPenalty << EOL;

    }  // correct input

  }  // for Inst
  
  return 0;

}
