/*
 * BAPC 2010 - Clocks (exact solution)
 * Jeroen Bransen
 */

import java.util.*;
import java.io.*;
import java.text.*;

public class clocks_jb {
   public static final double EPS = 1e-9;
   public static int W, H, C;
   public static int[] x, y, r;
   
   public static void main(String[] args) throws Exception {
      Scanner sc = new Scanner(System.in);
      int tests = sc.nextInt();
      while(tests-- > 0) {
         W = sc.nextInt();
         H = sc.nextInt();
         C = sc.nextInt();
         x = new int[C];
         y = new int[C];
         r = new int[C];
         for(int i = 0; i < C; i++) {
            x[i] = sc.nextInt();
            y[i] = sc.nextInt();
            r[i] = sc.nextInt();
         }
         double ret = 0;
         for(int i = 0; i < C; i++) {
            for(int j = i+1; j < C; j++) {
               for(int k = j+1; k < C; k++) {
                  // New clock touching 3 existing clocks
                  double nr = getRadius(r[i], r[j], r[k], dist(x[j], y[j], x[k], y[k]), dist(x[i], y[i], x[k], y[k]), dist(x[i], y[i], x[j], y[j]));
                  if(nr > W) continue;
                  // Construct centre-point based on radius
                  double a = 2 * (x[i] - x[j]);
                  double b = 2 * (y[i] - y[j]);
                  double c = 2 * (r[i] - r[j]);
                  double d = ((double)x[i] * x[i] + (double)y[i] * y[i] - (double)r[i] * r[i]) - ((double)x[j] * x[j] + (double)y[j] * y[j] - (double)r[j] * r[j]);
                  double aprime = 2 * (x[i] - x[k]);
                  double bprime = 2 * (y[i] - y[k]);
                  double cprime = 2 * (r[i] - r[k]);
                  double dprime = ((double)x[i] * x[i] + (double)y[i] * y[i] - (double)r[i] * r[i]) - ((double)x[k] * x[k] + (double)y[k] * y[k] - (double)r[k] * r[k]);
                  if(a * bprime - b * aprime == 0 || a * bprime - aprime * b == 0) continue;
                  double nx = ( bprime * d - b * dprime - bprime * c * nr + b * cprime * nr) / (a * bprime - b * aprime);
                  double ny = (-aprime * d + a * dprime + aprime * c * nr - a * cprime * nr) / (a * bprime - aprime * b);
                  if(fit(nx, ny, nr))
                     ret = Math.max(ret, nr);
               }
               // New clock touching 2 existing clocks and 1 wall
               for(int k = 0; k < 4; k++) {
                  // Use ABC-formula to solve (x[i] - x)^2 + (y[i] - nr)^2 == (r[i] + nr)^2
                  // and (x[i] - x)^2 + (y[i] - nr)^2 == (r[i] + nr)^2 for nr and x
                  // Formula is for wall y = 0, rotate existing clocks for other possibilities
                  int s = (k & 1) > 0 ? W : H;
                  if((k & 1) > 0) { int tmp = x[i]; x[i] = y[i]; y[i] = tmp; tmp = x[j]; x[j] = y[j]; y[j] = tmp; }
                  if((k & 2) > 0) { y[i] = s - y[i]; y[j] = s - y[j]; }
                  double g = ((double)y[j] + r[j]) / ((double)y[i] + r[i]);
                  double a = 1 - g;
                  double b = 2.0 * g * x[i] - 2.0 * x[j];
                  double c = (double)x[j] * x[j] + (double)y[j] * y[j] - (double)r[j] * r[j] - g * x[i] * x[i] - g * y[i] * y[i] + g * r[i] * r[i];
                  double d = b * b - 4 * a * c;
                  if(d >= 0 && (a != 0 || b != 0)) {
                     double x1, x2;
                     if(a == 0) {
                        x1 = x2 = -c / b;
                     } else {
                        x1 = (-b + Math.sqrt(d)) / (2 * a);
                        x2 = (-b - Math.sqrt(d)) / (2 * a);
                     }
                     double nr1 = ((double)x[i] * x[i] - 2.0 * x1 * x[i] + x1 * x1 + (double)y[i] * y[i] - (double)r[i] * r[i]) / (2.0 * ((double)y[i] + r[i]));
                     double nr2 = ((double)x[i] * x[i] - 2.0 * x2 * x[i] + x2 * x2 + (double)y[i] * y[i] - (double)r[i] * r[i]) / (2.0 * ((double)y[i] + r[i]));
                     double y1 = nr1;
                     double y2 = nr2;
                     // Rotate clocks back
                     if((k & 2) > 0) { y[i] = s - y[i]; y[j] = s - y[j]; }
                     if((k & 1) > 0) { int tmp = x[i]; x[i] = y[i]; y[i] = tmp; tmp = x[j]; x[j] = y[j]; y[j] = tmp; }
                     // Rotate the results
                     if((k & 2) > 0) { y1 = s - y1; y2 = s - y2; }
                     if((k & 1) > 0) { double tmp = x1; x1 = y1; y1 = tmp; tmp = x2; x2 = y2; y2 = tmp; }
                     // Check results
                     if(fit(x1, y1, nr1))
                        ret = Math.max(ret, nr1);
                     if(fit(x2, y2, nr2))
                        ret = Math.max(ret, nr2);
                  } else {
                     // Rotate back
                     if((k & 2) > 0) { y[i] = s - y[i]; y[j] = s - y[j]; }
                     if((k & 1) > 0) { int tmp = x[i]; x[i] = y[i]; y[i] = tmp; tmp = x[j]; x[j] = y[j]; y[j] = tmp; }
                  }
               }
            }
            // New clock touching 1 existing clock and 2 walls
            for(int j = 0; j < 4; j++) {
               // In a corner
               // Use ABC-formula to solve (x[i] - nr)^2 + (y[i] - nr)^2 == (r[i] + nr)^2
               // Formula is for left-upper corner, mirror existing clock for other possibilities
               if((j & 1) > 0) x[i] = W - x[i];
               if((j & 2) > 0) y[i] = H - y[i];
               double a = 1;
               double b = -2.0 * ((double)x[i] + y[i] + r[i]);
               double c = (double)x[i] * x[i] + (double)y[i] * y[i] - (double)r[i] * r[i];
               if((j & 1) > 0) x[i] = W - x[i];
               if((j & 2) > 0) y[i] = H - y[i];
               double d = b * b - 4 * a * c;
               if(d >= 0) {
                  double nr1 = (-b + Math.sqrt(d)) / (2 * a);
                  double nr2 = (-b - Math.sqrt(d)) / (2 * a);
                  if(fit((j & 1) > 0 ? W - nr1 : nr1, (j & 2) > 0 ? H - nr1 : nr1, nr1))
                     ret = Math.max(ret, nr1);
                  if(fit((j & 1) > 0 ? W - nr2 : nr2, (j & 2) > 0 ? H - nr2 : nr2, nr2))
                     ret = Math.max(ret, nr2);
               }
               // 2 opposite walls (vertical walls)
               a = 1;
               b = -2.0 * y[i];
               c = (double)x[i] * x[i] + (double)y[i] * y[i] - (double)x[i] * W - (double)r[i] * r[i] - (double)r[i] * W;
               d = b * b - 4 * a * c;
               if(d >= 0) {
                  double x1 = W / 2.0;
                  double nr = W / 2.0;
                  double y1 = (-b + Math.sqrt(d)) / (2 * a);
                  double y2 = (-b - Math.sqrt(d)) / (2 * a);
                  if(fit(x1, y1, nr) || fit(x1, y2, nr))
                     ret = Math.max(ret, nr);
               }
               // 2 opposite walls (horizontal walls)
               a = 1;
               b = -2.0 * x[i];
               c = (double)x[i] * x[i] + (double)y[i] * y[i] - (double)y[i] * H - (double)r[i] * r[i] - (double)r[i] * H;
               d = b * b - 4 * a * c;
               if(d >= 0) {
                  double y1 = H / 2.0;
                  double nr = H / 2.0;
                  double x1 = (-b + Math.sqrt(d)) / (2 * a);
                  double x2 = (-b - Math.sqrt(d)) / (2 * a);
                  if(fit(x1, y1, nr) || fit(x2, y1, nr))
                     ret = Math.max(ret, nr);
               }
            }
         }
         
         // New clock touching 3 walls
         double r3w = Math.min(H,W) / 2.0;
         if(fit(r3w,r3w,r3w) || fit(W-r3w,r3w,r3w) || fit(r3w,H-r3w,r3w) || fit(W-r3w,W-r3w,r3w))
            ret = Math.max(ret, r3w);
         
         System.out.println(ret);
      }
   }
   
   // Apollonius' Tangency Problem
   public static double getRadius(double a, double b, double c, double A, double B, double C) {
      double c0 = A*A*B*B*C*C - (A*A*B*B + A*A*C*C + B*B*C*C)*(a*a + b*b + c*c)
                              - (a*a*b*b + a*a*c*c + b*b*c*c)*(A*A + B*B + C*C)
                              + (A*A*B*B*c*c + A*A*b*b*C*C + a*a*B*B*C*C) + 2*(a*a*b*b*C*C + a*a*B*B*c*c + A*A*b*b*c*c)
                              + (A*A*A*A*a*a + B*B*B*B*b*b + C*C*C*C*c*c) +   (a*a*a*a*A*A + b*b*b*b*B*B + c*c*c*c*C*C);
      double c1 = 2*A*A * ((-a+b+c)*(-a*a + b*b + c*c) - (-a*a*a + b*b*b + c*c*c) - a*(-A*A + B*B + C*C))
                + 2*B*B * (( a-b+c)*( a*a - b*b + c*c) - ( a*a*a - b*b*b + c*c*c) - b*( A*A - B*B + C*C))
                + 2*C*C * (( a+b-c)*( a*a + b*b - c*c) - ( a*a*a + b*b*b - c*c*c) - c*( A*A + B*B - C*C));
      double c2 = 4 * ((a-b) * (a-c) * A * A + (b-a) * (b-c) * B * B + (c-a) * (c-b) * C * C) - (A+B+C) * (-A+B+C) * (A-B+C) * (A+B-C);
      double D = c1 * c1 - 4 * c0 * c2;
      if(D < 0) return W+1;
      return Math.max((Math.sqrt(D) - c1) / (2 * c2), (-Math.sqrt(D) - c1) / (2 * c2));
   }
   
   public static double dist(double x1, double y1, double x2, double y2) {
      double dx = x1 - x2;
      double dy = y1 - y2;
      return Math.sqrt(dx*dx+dy*dy);
   }
   
   public static boolean fit(double nx, double ny, double nr) {
      if(nx - nr < -EPS || nx + nr > W + EPS || ny - nr < -EPS || ny + nr > H + EPS)
         return false;
      for(int i = 0; i < C; i++)
         if(dist(x[i], y[i], nx, ny) + EPS < nr + r[i])
            return false;
      return true;
   }
}
