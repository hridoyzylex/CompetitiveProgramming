/*
 * BAPC 2010
 * Jeroen Bransen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAXN 100000

#define MAX(a, b) ((a) > (b) ? (a) : (b));

int x[MAXN];
int y[MAXN];

void testcase() {
	int i, maxi, j, k, N;
	scanf("%d\n", &N);
	for(i = 0; i < N; i++)
		scanf("%d", &x[i]);
	for(i = 0; i < N; i++)
		scanf("%d", &y[i]);
	maxi = 0;
	for(i = 0; i < N; i = maxi + 1) {
		for(k = i; x[i] != y[k]; k++);
		maxi = k;
		for(j = i+1; maxi != j-1; j++) {
			for(k = i; x[j] != y[k]; k++);
			maxi = MAX(maxi, k);
		}
		if(i) printf(" ");
		printf("%d-%d",i+1,maxi+1);
	}
	printf("\n");
}

int main() {
	int t;
	scanf("%d\n", &t);
	while(t--) testcase();
	return 0;
}
